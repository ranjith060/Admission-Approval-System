<?php
session_start();
header("Content-Type: application/json");
require_once '../../config/db.php';

// Only Admin Access
if (!isset($_SESSION['role_code']) || $_SESSION['role_code'] !== 'ADMIN') {
    echo json_encode(["status" => "error", "message" => "Unauthorized Access"]);
    exit();
}

$app_no = $_POST['app_no'];

try {
    $conn->beginTransaction();

    // 1. Get Application Details
    $stmt = $conn->prepare("SELECT a.*, c.course_short, ay.ay_short_code 
                            FROM admission_applications a 
                            JOIN course_master c ON a.course_code = c.course_code
                            JOIN academic_years ay ON ay.status = 'Active'
                            WHERE a.application_no = ?");
    $stmt->execute([$app_no]);
    $app = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$app) throw new Exception("Application Not Found");
    if ($app['app_status'] === 'Admitted') throw new Exception("Student Already Admitted!");

    // 2. GENERATE STUDENT ID (318 + 2526 + CSE + 0001)
    $college_code = "318";
    $ay_code = $app['ay_short_code']; // 2526
    $course_short = strtoupper($app['course_short']); // CSE
    
    // Sequence Name: SEQ_318_2526_CSE
    $seq_name = "SEQ_{$college_code}_{$ay_code}_{$course_short}";

    // Check Sequence Exists
    $check_seq = $conn->prepare("SELECT last_value FROM system_sequences WHERE seq_code = ?");
    $check_seq->execute([$seq_name]);
    
    if ($check_seq->rowCount() == 0) {
        // Create new sequence if not exists
        $conn->prepare("INSERT INTO system_sequences (seq_code, last_value) VALUES (?, 0)")->execute([$seq_name]);
        $next_val = 1;
    } else {
        $next_val = $check_seq->fetchColumn() + 1;
    }

    // Update Sequence
    $conn->prepare("UPDATE system_sequences SET last_value = ? WHERE seq_code = ?")->execute([$next_val, $seq_name]);

    // Format ID: 3182526CSE0001
    $student_id = $college_code . $ay_code . $course_short . str_pad($next_val, 4, '0', STR_PAD_LEFT);

    // 3. Get Parent Details (Father)
    $p_stmt = $conn->prepare("SELECT name, mobile_no FROM admission_family WHERE application_no = ? AND relation_type='Father'");
    $p_stmt->execute([$app_no]);
    $parent = $p_stmt->fetch(PDO::FETCH_ASSOC);
    $parent_name = $parent['name'] ?? 'Guardian';
    $parent_mobile = $parent['mobile_no'] ?? '';

    // 4. INSERT INTO STUDENT MASTER
    $sql_master = "INSERT INTO student_master (
        student_id, user_uid, application_no, register_no, batch_year, course_code, 
        admission_type, quota_type, student_name, dob, gender, blood_group, 
        community, mobile_no, email, parent_name, parent_mobile, address, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active')";

    $batch = "20" . substr($ay_code, 0, 2) . "-" . (20 . substr($ay_code, 0, 2) + 3); // 2025-2028

    $insert = $conn->prepare($sql_master);
    $insert->execute([
        $student_id, 
        $app['user_uid'], 
        $app['application_no'], 
        $student_id, // Register No initially same as Student ID
        $batch, 
        $app['course_code'], 
        $app['admission_type'], 
        $app['quota_type'], 
        $app['student_name'], 
        $app['dob'], 
        $app['gender'], 
        $app['blood_group'], 
        $app['community'], 
        $app['student_mobile'], 
        $app['student_email'], 
        $parent_name, 
        $parent_mobile, 
        $app['address_communication']
    ]);

    // 5. UPDATE Application Status
    $update = $conn->prepare("UPDATE admission_applications SET app_status = 'Admitted' WHERE application_no = ?");
    $update->execute([$app_no]);

    $conn->commit();
    echo json_encode(["status" => "success", "message" => "Admission Success! Student ID: " . $student_id]);

} catch (Exception $e) {
    if($conn->inTransaction()) $conn->rollBack();
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
?>