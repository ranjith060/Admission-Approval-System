<?php
require_once '../../config/db.php';
header('Content-Type: application/json');

$app_no = $_POST['app_no'];
$status = $_POST['status']; // Admitted, Rejected, Waiting
$remarks = $_POST['remarks'] ?? ''; // Optional reason

try {
    $conn->beginTransaction();

    // Update Status & Remarks
    $stmt = $conn->prepare("UPDATE admission_applications SET app_status = ?, admin_remarks = ? WHERE application_no = ?");
    $stmt->execute([$status, $remarks, $app_no]);

    // If Admitted, Move to Student Master (Previous logic here...)
    // ... (Keep your existing Admitted Logic here) ...

    $conn->commit();
    echo json_encode(["status" => "success", "message" => "Status Updated to $status"]);

} catch (Exception $e) {
    $conn->rollBack();
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
?>