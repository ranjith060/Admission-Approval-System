<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

require_once '../../config/db.php';

try {
    // Select basic details for the list view
    $sql = "SELECT application_no, student_name, course_code_pref, app_status, application_date 
            FROM admission_applications 
            ORDER BY application_date DESC";
            
    $stmt = $conn->query($sql);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(["status" => "success", "data" => $students]);

} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
?>