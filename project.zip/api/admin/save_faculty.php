<?php
session_start();
header("Content-Type: application/json");
require_once '../../config/db.php';

// Only Admin Access
if (!isset($_SESSION['role_code']) || $_SESSION['role_code'] !== 'ADMIN') {
    echo json_encode(["status" => "error", "message" => "Unauthorized Access"]);
    exit();
}

$action = $_POST['action'] ?? '';

try {
    // ---------------------------------------------------------
    // 1. ADD / UPDATE FACULTY
    // ---------------------------------------------------------
    if ($action == 'add' || $action == 'update') {
        
        $conn->beginTransaction();

        $faculty_id = $_POST['faculty_id'];
        $is_new = empty($faculty_id);

        // Generate ID if New
        if ($is_new) {
            $year = date('y'); // 26
            $stmt = $conn->query("SELECT count(*) FROM faculty_master");
            $count = $stmt->fetchColumn() + 1;
            $faculty_id = "FAC" . $year . str_pad($count, 3, '0', STR_PAD_LEFT);
        }

        // Handle File Upload (Photo)
        $photo_path = null;
        if (!empty($_FILES['profile_photo']['name'])) {
            $target_dir = "../../uploads/faculty/";
            if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);
            
            $ext = pathinfo($_FILES['profile_photo']['name'], PATHINFO_EXTENSION);
            $fname = $faculty_id . "_PHOTO." . $ext;
            
            if(move_uploaded_file($_FILES['profile_photo']['tmp_name'], $target_dir.$fname)) {
                $photo_path = "uploads/faculty/" . $fname;
            }
        }

        if ($is_new) {
            // INSERT
            $sql = "INSERT INTO faculty_master (
                faculty_id, first_name, last_name, email, phone, course_code, 
                designation, qualification, specialization, date_of_joining, 
                profile_photo, status, is_deleted
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', 0)";
            
            $stmt = $conn->prepare($sql);
            $stmt->execute([
                $faculty_id, $_POST['first_name'], $_POST['last_name'], $_POST['email'], 
                $_POST['phone'], $_POST['course_code'], $_POST['designation'], 
                $_POST['qualification'], $_POST['specialization'], $_POST['date_of_joining'], 
                $photo_path // New Photo
            ]);
            $msg = "Faculty Added Successfully!";

        } else {
            // UPDATE
            // Photo logic: If new photo uploaded, update it. Else keep old.
            $photo_sql = $photo_path ? ", profile_photo=?" : "";
            
            $sql = "UPDATE faculty_master SET 
                    first_name=?, last_name=?, email=?, phone=?, course_code=?, 
                    designation=?, qualification=?, specialization=?, date_of_joining=? 
                    $photo_sql 
                    WHERE faculty_id=?";
            
            $params = [
                $_POST['first_name'], $_POST['last_name'], $_POST['email'], 
                $_POST['phone'], $_POST['course_code'], $_POST['designation'], 
                $_POST['qualification'], $_POST['specialization'], $_POST['date_of_joining']
            ];
            
            if($photo_path) $params[] = $photo_path;
            $params[] = $faculty_id; // Where condition

            $stmt = $conn->prepare($sql);
            $stmt->execute($params);
            $msg = "Faculty Details Updated!";
        }

        $conn->commit();
        echo json_encode(["status" => "success", "message" => $msg]);
    }

    // ---------------------------------------------------------
    // 2. FETCH SINGLE FACULTY (For Edit/View)
    // ---------------------------------------------------------
    elseif ($action == 'fetch_single') {
        $stmt = $conn->prepare("SELECT * FROM faculty_master WHERE faculty_id = ?");
        $stmt->execute([$_POST['faculty_id']]);
        $data = $stmt->fetch(PDO::FETCH_ASSOC);
        echo json_encode($data);
    }

    // ---------------------------------------------------------
    // 3. TOGGLE STATUS (Active/Inactive)
    // ---------------------------------------------------------
    elseif ($action == 'toggle_status') {
        $stmt = $conn->prepare("UPDATE faculty_master SET status = ? WHERE faculty_id = ?");
        $stmt->execute([$_POST['status'], $_POST['faculty_id']]);
        echo json_encode(["status" => "success", "message" => "Status Changed"]);
    }

    // ---------------------------------------------------------
    // 4. DELETE FACULTY (Soft Delete)
    // ---------------------------------------------------------
    elseif ($action == 'delete') {
        $stmt = $conn->prepare("UPDATE faculty_master SET is_deleted = 1 WHERE faculty_id = ?");
        $stmt->execute([$_POST['faculty_id']]);
        echo json_encode(["status" => "success", "message" => "Moved to Recycle Bin"]);
    }

    else {
        throw new Exception("Invalid Action");
    }

} catch (Exception $e) {
    if($conn->inTransaction()) $conn->rollBack();
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
?>