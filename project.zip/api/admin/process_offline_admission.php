<?php
// 1. Silent Mode (Prevents random text in response)
ob_start();
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 0); 

header("Content-Type: application/json");

require_once '../../config/db.php';
require_once '../../includes/functions.php';

try {
    // Check Admin Login
    if (!isset($_SESSION['role_code']) || $_SESSION['role_code'] !== 'ADMIN') {
        throw new Exception("Unauthorized Access");
    }

    $conn->beginTransaction();

    // ---------------------------------------------------------
    // A. CREATE USER ACCOUNT (STUDENT LOGIN)
    // ---------------------------------------------------------
    $ay_code = "2526"; // Current Year Short Code
    $reg_no = "REG" . $ay_code . rand(1000, 9999); // Unique User ID
    $email = $_POST['email'];
    $mobile = $_POST['mobile_no'];
    $pass_hash = password_hash("Welcome@123", PASSWORD_DEFAULT);

    $sql_user = "INSERT INTO users (user_uid, username, email, password_hash, role_code, mobile_no) VALUES (?, ?, ?, ?, 'STUDENT', ?)";
    $stmt_u = $conn->prepare($sql_user);
    $stmt_u->execute([$reg_no, $_POST['student_name'], $email, $pass_hash, $mobile]);

    // ---------------------------------------------------------
    // B. CREATE APPLICATION (Dynamic Array Method - No Errors)
    // ---------------------------------------------------------
    $app_no = generateApplicationID($conn);
    $percentage = floatval(str_replace('%', '', $_POST['percentage'] ?? 0));

    // Data Mapping (Correct Column Names from your DB)
    $app_data = [
        'application_no'        => $app_no,
        'user_uid'              => $reg_no,
        'course_code'           => $_POST['course_code'],
        'admission_type'        => $_POST['admission_type'],
        'qualification'         => ($_POST['admission_type'] == 'First Year' ? 'SSLC' : 'HSC'),
        'quota_type'            => $_POST['quota'],
        'student_name'          => $_POST['student_name'],
        'dob'                   => $_POST['dob'],
        'age'                   => $_POST['age'],
        'gender'                => $_POST['gender'],
        'blood_group'           => $_POST['blood_group'],
        'community'             => $_POST['community'],
        'caste_name'            => $_POST['caste'],
        'religion'              => $_POST['religion'],
        'mother_tongue'         => 'Tamil', // Or add field in form
        'nationality'           => 'Indian',
        'student_mobile'        => $mobile,        // Corrected Name
        'student_email'         => $email,         // Corrected Name
        'aadhar_no'             => $_POST['aadhar_no'],
        'emis_no'               => $_POST['emis_no'] ?? NULL,
        'umis_no'               => $_POST['umis_no'] ?? NULL,
        'address_communication' => $_POST['address'],
        'school_name'           => $_POST['school_name'],
        'school_place'          => $_POST['school_place'],
        'school_reg_no'         => $_POST['reg_no'], // Corrected Name
        'year_of_passing'       => $_POST['year_passing'],
        'medium_of_instruction' => $_POST['medium'],
        'part_1_language'       => 'Tamil', // Or add input
        'total_marks'           => $_POST['total_marks'],
        'max_total_marks'       => ($_POST['admission_type'] == 'First Year' ? 500 : 600),
        'percentage'            => $percentage,
        'bank_name'             => $_POST['bank_name'] ?? NULL,
        'bank_branch'           => $_POST['bank_branch'] ?? NULL,
        'account_no'            => $_POST['acc_no'] ?? NULL,
        'ifsc_code'             => $_POST['ifsc'] ?? NULL,
        'transport_required'    => $_POST['transport'] ?? 'No',
        'transport_place'       => $_POST['boarding_place'] ?? NULL,
        'hostel_required'       => $_POST['hostel'] ?? 'No',
        'app_status'            => 'Admitted'
    ];

    // Auto-Generate Query
    $columns = implode(", ", array_keys($app_data));
    $placeholders = implode(", ", array_fill(0, count($app_data), "?"));
    $stmt_app = $conn->prepare("INSERT INTO admission_applications ($columns) VALUES ($placeholders)");
    $stmt_app->execute(array_values($app_data));

    // ---------------------------------------------------------
    // C. INSERT MARKS
    // ---------------------------------------------------------
    if (isset($_POST['sub_name']) && is_array($_POST['sub_name'])) {
        $subjects = $_POST['sub_name'];
        $sec_marks = $_POST['sec_mark'];
        $max_marks = $_POST['max_mark'];
        
        $sql_marks = "INSERT INTO admission_marks (application_no, subject_name, marks_obtained, max_marks) VALUES (?,?,?,?)";
        $stmt_m = $conn->prepare($sql_marks);
        
        for($i=0; $i<count($subjects); $i++) {
            $stmt_m->execute([$app_no, $subjects[$i], $sec_marks[$i], $max_marks[$i]]);
        }
    }

    // ---------------------------------------------------------
    // D. INSERT FAMILY
    // ---------------------------------------------------------
    // Use 'admission_family' (Matches your new schema)
    $sql_fam = "INSERT INTO admission_family (application_no, relation_type, name, mobile_no) VALUES (?,?,?,?)";
    $stmt_f = $conn->prepare($sql_fam);
    
    // Father (Required)
    $stmt_f->execute([$app_no, 'Father', $_POST['father_name'], $mobile]); // Using student mobile as dummy if not taken separately
    
    if(!empty($_POST['mother_name'])) {
        $stmt_f->execute([$app_no, 'Mother', $_POST['mother_name'], '']);
    }
    if(!empty($_POST['guardian_name'])) {
        $stmt_f->execute([$app_no, 'Guardian', $_POST['guardian_name'], '']);
    }

    // ---------------------------------------------------------
    // E. INSERT REFERENCE
    // ---------------------------------------------------------
    if(!empty($_POST['ref_type']) && $_POST['ref_type'] != 'Direct') {
        $conn->prepare("INSERT INTO admission_references (application_no, reference_type, ref_name, ref_info) VALUES (?,?,?,?)")
             ->execute([$app_no, $_POST['ref_type'], $_POST['ref_name'] ?? '', $_POST['ref_detail'] ?? '']);
    }

    // ---------------------------------------------------------
    // F. FEE TRANSACTION
    // ---------------------------------------------------------
    $conn->prepare("INSERT INTO fee_transactions (application_no, payment_mode, amount_paid, payment_date, payment_status, remarks) VALUES (?, 'Cash', ?, ?, 'Success', 'Offline Admission')")
         ->execute([$app_no, $_POST['fee_amount'], $_POST['pay_date']]);

    // ---------------------------------------------------------
    // G. FILE UPLOADS
    // ---------------------------------------------------------
    $uploads = [
        'photo' => 'PHOTO', 
        'doc_aadhar' => 'AADHAR', 
        'doc_comm' => 'COMMUNITY', 
        'doc_receipt' => 'RECEIPT',
        'doc_tc' => 'TC',
        'doc_mark' => 'MARK_SHEET'
    ];
    $target_dir = "../../uploads/";
    if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);
    
    foreach($uploads as $field => $dtype) {
        if(!empty($_FILES[$field]['name'])) {
            $ext = pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION);
            $fname = $app_no . "_" . $dtype . "." . $ext;
            
            if(move_uploaded_file($_FILES[$field]['tmp_name'], $target_dir.$fname)) {
                $conn->prepare("INSERT INTO admission_documents (application_no, doc_type, file_path, verification_status) VALUES (?, ?, ?, 'Verified')")
                     ->execute([$app_no, $dtype, "uploads/".$fname]);
            }
        }
    }

    // ---------------------------------------------------------
    // H. FINAL: STUDENT MASTER (Generate 318... ID)
    // ---------------------------------------------------------
    $dept = $conn->query("SELECT course_short FROM course_master WHERE course_code='{$_POST['course_code']}'")->fetchColumn();
    $prefix = "318" . $ay_code . strtoupper($dept);
    
    // Sequence Logic
    $conn->query("INSERT IGNORE INTO system_sequences (seq_code, last_value) VALUES ('$prefix', 0)");
    $conn->query("UPDATE system_sequences SET last_value = last_value + 1 WHERE seq_code = '$prefix'");
    $seq = $conn->query("SELECT last_value FROM system_sequences WHERE seq_code = '$prefix'")->fetchColumn();
    
    $student_id = $prefix . str_pad($seq, 4, '0', STR_PAD_LEFT);
    $batch = "20".substr($ay_code,0,2) . "-" . (20 . substr($ay_code,0,2)+3);

    // Insert Student (Dynamic Array again for safety)
    $stu_data = [
        'student_id'    => $student_id,
        'user_uid'      => $reg_no,
        'application_no'=> $app_no,
        'register_no'   => $student_id, // Default same as ID
        'batch_year'    => $batch,
        'course_code'   => $_POST['course_code'],
        'admission_type'=> $_POST['admission_type'],
        'quota_type'    => $_POST['quota'],
        'student_name'  => $_POST['student_name'],
        'dob'           => $_POST['dob'],
        'gender'        => $_POST['gender'],
        'blood_group'   => $_POST['blood_group'],
        'community'     => $_POST['community'],
        'mobile_no'     => $mobile,
        'email'         => $email,
        'parent_name'   => $_POST['father_name'],
        'address'       => $_POST['address'],
        'status'        => 'Active'
    ];

    $s_cols = implode(", ", array_keys($stu_data));
    $s_vals = implode(", ", array_fill(0, count($stu_data), "?"));
    
    $conn->prepare("INSERT INTO student_master ($s_cols) VALUES ($s_vals)")->execute(array_values($stu_data));

    // Success!
    $conn->commit();
    ob_clean();
    echo json_encode(["status" => "success", "student_id" => $student_id]);

} catch (Exception $e) {
    if($conn->inTransaction()) $conn->rollBack();
    ob_clean();
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
?>