<?php
header("Content-Type: application/json");
require_once '../../config/db.php';

$course_code = $_POST['course'] ?? '1052'; // Default CSE

try {
    $conn->beginTransaction();

    // 1. Reset Previous Allocation (Safety)
    $stmt = $conn->prepare("UPDATE admission_applications SET app_status='Submitted', quota_type=NULL, allotted_category=NULL WHERE course_code_pref=? AND app_status IN ('Submitted','Admitted')");
    $stmt->execute([$course_code]);

    // 2. Get Total Seats & Reservation Rules
    $stmt = $conn->prepare("SELECT total_seats FROM course_master WHERE course_code = ?");
    $stmt->execute([$course_code]);
    $total_seats = $stmt->fetchColumn() ?: 60;

    $gq_seats = floor($total_seats * 0.50); // 50% Govt Quota
    $mq_seats = $total_seats - $gq_seats;  // 50% Mgmt Quota

    // DOTE Rules (Seats Calculation)
    $rules = ['OC'=>31, 'BC'=>26.5, 'BCM'=>3.5, 'MBC'=>20, 'SC'=>15, 'SCA'=>3, 'ST'=>1];
    $limits = [];
    foreach ($rules as $comm => $pct) {
        $limits[$comm] = round(($gq_seats * $pct) / 100);
    }
    // Adjust rounding (Put extra in OC)
    if(array_sum($limits) < $gq_seats) $limits['OC'] += ($gq_seats - array_sum($limits));

    // 3. Get Merit List (Sorted by Marks)
    $sql = "SELECT application_no, community_class FROM admission_applications 
            WHERE course_code_pref=? AND app_status='Submitted' 
            ORDER BY calculated_percentage DESC";
    $stmt = $this->conn->prepare($sql);
    $stmt->execute([$course_code]);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 4. Start Allocation Loop
    $filled = ['OC'=>0, 'BC'=>0, 'BCM'=>0, 'MBC'=>0, 'SC'=>0, 'SCA'=>0, 'ST'=>0];
    $mq_filled = 0;

    foreach ($students as $stu) {
        $app_no = $stu['application_no'];
        $my_comm = $stu['community_class']; // Ex: MBC
        $assigned_quota = null;
        $assigned_cat = null;

        // --- GOVT QUOTA LOGIC ---
        // Rule 1: Check OC (Open to ALL)
        if ($filled['OC'] < $limits['OC']) {
            $assigned_quota = 'GOVT';
            $assigned_cat = 'OC';
            $filled['OC']++;
        }
        // Rule 2: Check Own Community
        elseif ($filled[$my_comm] < $limits[$my_comm]) {
            $assigned_quota = 'GOVT';
            $assigned_cat = $my_comm;
            $filled[$my_comm]++;
        }
        // Rule 3: Overflow to Management Quota
        elseif ($mq_filled < $mq_seats) {
            $assigned_quota = 'MGMT';
            $assigned_cat = 'MGMT'; // Or separate quota logic
            $mq_filled++;
        }
        // Rule 4: Waiting List (No Seats)
        else {
            continue; // Skip update
        }

        // 5. Update Database
        if ($assigned_quota) {
            $upd = $conn->prepare("UPDATE admission_applications SET app_status='Admitted', quota_type=?, allotted_category=? WHERE application_no=?");
            $upd->execute([$assigned_quota, $assigned_cat, $app_no]);
        }
    }

    $conn->commit();
    echo json_encode(["status" => "success", "message" => "Auto-Allocation Completed!", "stats" => $filled]);

} catch (Exception $e) {
    $conn->rollBack();
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
?>