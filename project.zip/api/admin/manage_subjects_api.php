<?php
// api/admin/manage_subjects_api.php
header("Content-Type: application/json");
require_once '../../config/db.php';
require_once '../../includes/auth_session.php';

// Only Admin access
checkLogin('ADMIN');

$action = $_POST['action'] ?? '';

try {
    if ($action == 'add') {
        // 1. Check Duplicate Subject Code
        $check = $conn->prepare("SELECT subject_code FROM subjects WHERE subject_code = ?");
        $check->execute([$_POST['subject_code']]);
        if($check->rowCount() > 0) {
            throw new Exception("Subject Code already exists!");
        }

        // 2. ADD NEW SUBJECT
        $sql = "INSERT INTO subjects (subject_code, course_code, semester_number, subject_name, L, T, P, min_pass_percentage, max_percentage, periods, credits, regulation, subject_type, end_exam, elective_type) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            trim($_POST['subject_code']), 
            $_POST['course_code'], 
            $_POST['semester_number'], 
            trim($_POST['subject_name']),
            $_POST['L'] ?? 0, 
            $_POST['T'] ?? 0, 
            $_POST['P'] ?? 0, 
            $_POST['min_pass_percentage'] ?? 35, 
            $_POST['max_percentage'] ?? 100,
            $_POST['periods'] ?? 0, 
            $_POST['credits'] ?? 0, 
            trim($_POST['regulation']), 
            $_POST['subject_type'],
            $_POST['end_exam'], 
            $_POST['elective_type']
        ]);

        echo json_encode(["status" => "success", "message" => "Subject Added Successfully"]);

    } elseif ($action == 'update') {
        // UPDATE SUBJECT
        $sql = "UPDATE subjects SET 
                course_code=?, semester_number=?, subject_name=?, L=?, T=?, P=?, 
                min_pass_percentage=?, max_percentage=?, periods=?, credits=?, regulation=?, 
                subject_type=?, end_exam=?, elective_type=? 
                WHERE subject_code=?";
        
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            $_POST['course_code'], 
            $_POST['semester_number'], 
            trim($_POST['subject_name']),
            $_POST['L'] ?? 0, 
            $_POST['T'] ?? 0, 
            $_POST['P'] ?? 0, 
            $_POST['min_pass_percentage'], 
            $_POST['max_percentage'],
            $_POST['periods'] ?? 0, 
            $_POST['credits'] ?? 0, 
            trim($_POST['regulation']), 
            $_POST['subject_type'],
            $_POST['end_exam'], 
            $_POST['elective_type'], 
            trim($_POST['subject_code'])
        ]);

        echo json_encode(["status" => "success", "message" => "Subject Updated Successfully"]);

    } elseif ($action == 'delete') {
        // DELETE SUBJECT
        $stmt = $conn->prepare("DELETE FROM subjects WHERE subject_code = ?");
        $stmt->execute([$_POST['subject_code']]);
        
        if ($stmt->rowCount() > 0) {
            echo json_encode(["status" => "success", "message" => "Subject Deleted Successfully"]);
        } else {
            throw new Exception("Subject ID not found or already deleted.");
        }

    } elseif ($action == 'fetch_single') {
        // FETCH SINGLE SUBJECT FOR EDIT
        $stmt = $conn->prepare("SELECT * FROM subjects WHERE subject_code = ?");
        $stmt->execute([$_POST['subject_code']]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if($row) {
            echo json_encode($row);
        } else {
            throw new Exception("Subject Details Not Found");
        }
    } else {
        throw new Exception("Invalid Action");
    }

} catch (Exception $e) {
    // Duplicate Entry Catch (Extra Safety)
    if (strpos($e->getMessage(), 'Duplicate entry') !== false) {
        echo json_encode(["status" => "error", "message" => "Subject Code already exists!"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Error: " . $e->getMessage()]);
    }
}
?>