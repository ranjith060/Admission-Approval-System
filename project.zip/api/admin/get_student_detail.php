<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
require_once '../../config/db.php';

$id = $_GET['id'];

try {
    // 1. Basic Info
    $stmt = $conn->prepare("SELECT * FROM admission_applications WHERE application_no = ?");
    $stmt->execute([$id]);
    $info = $stmt->fetch(PDO::FETCH_ASSOC);

    // 2. Marks
    $stmt = $conn->prepare("SELECT * FROM admission_marks WHERE application_no = ?");
    $stmt->execute([$id]);
    $marks = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 3. Documents
    $stmt = $conn->prepare("SELECT doc_type, file_path FROM admission_documents WHERE application_no = ?");
    $stmt->execute([$id]);
    $doc_rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Convert Docs to Key-Value pair for easy JS access
    $docs = [];
    foreach($doc_rows as $row) {
        $docs[$row['doc_type']] = $row['file_path'];
    }

    echo json_encode(["status" => "success", "data" => ["info" => $info, "marks" => $marks, "docs" => $docs]]);

} catch (Exception $e) { echo json_encode(["status" => "error", "message" => $e->getMessage()]); }
?>