<?php
require_once '../../config/db.php';
require_once '../../includes/auth_session.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_uid'])) {
    echo json_encode(["status" => "error", "message" => "Unauthorized Access"]);
    exit();
}

$user_id = $_SESSION['user_uid'];
$current_pass = $_POST['current_password'] ?? '';
$new_pass = $_POST['new_password'] ?? '';
$confirm_pass = $_POST['confirm_password'] ?? '';

if (empty($current_pass) || empty($new_pass)) {
    echo json_encode(["status" => "error", "message" => "All fields are required"]);
    exit();
}

if ($new_pass !== $confirm_pass) {
    echo json_encode(["status" => "error", "message" => "New passwords do not match"]);
    exit();
}

try {
    // FIX: Column name changed from 'password' to 'password_hash'
    $stmt = $conn->prepare("SELECT password_hash FROM users WHERE user_uid = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo json_encode(["status" => "error", "message" => "User not found"]);
        exit();
    }

    // FIX: Verify using 'password_hash'
    if (!password_verify($current_pass, $user['password_hash'])) {
        echo json_encode(["status" => "error", "message" => "Incorrect Current Password"]);
        exit();
    }

    $new_hashed_pass = password_hash($new_pass, PASSWORD_DEFAULT);
    
    // FIX: Update 'password_hash' column
    $updateStmt = $conn->prepare("UPDATE users SET password_hash = ? WHERE user_uid = ?");
    if ($updateStmt->execute([$new_hashed_pass, $user_id])) {
        echo json_encode(["status" => "success", "message" => "Password updated successfully"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to update password"]);
    }

} catch (PDOException $e) {
    echo json_encode(["status" => "error", "message" => "Database Error: " . $e->getMessage()]);
}
?>