<?php
// Error Handling Setup
ob_start();
error_reporting(E_ALL);
ini_set('display_errors', 0);
header("Content-Type: application/json");

$response = [];

try {
    require_once '../../config/db.php';
    require_once '../../includes/functions.php';

    // 1. Get Data
    $data = json_decode(file_get_contents("php://input"));

    if (empty($data->username) || empty($data->email) || empty($data->password) || empty($data->mobile)) {
        throw new Exception("Please fill all details.");
    }

    // 2. Check if Email Exists
    $stmt = $conn->prepare("SELECT email FROM users WHERE email = ?");
    $stmt->execute([$data->email]);
    if ($stmt->rowCount() > 0) {
        throw new Exception("Email already registered!");
    }

    // 3. Register User
    $conn->beginTransaction();

    $custom_id = generateUserID($conn); // Calls function from Step 2
    $hashed_pass = password_hash($data->password, PASSWORD_DEFAULT);

    // Insert into USERS table
    $sql = "INSERT INTO users (user_uid, username, email, password_hash, role_code, mobile_no) 
            VALUES (?, ?, ?, ?, 'STUDENT', ?)";
    
    $stmt = $conn->prepare($sql);
    if(!$stmt->execute([$custom_id, $data->username, $data->email, $hashed_pass, $data->mobile])) {
        throw new Exception("Database Insert Failed.");
    }

    $conn->commit();

    $response = [
        "status" => "success", 
        "message" => "Registration Successful! Your ID: $custom_id. Login now.",
        "redirect" => "index.php"
    ];

} catch (Exception $e) {
    if(isset($conn) && $conn->inTransaction()){ $conn->rollBack(); }
    $response = ["status" => "error", "message" => $e->getMessage()];
}

ob_clean();
echo json_encode($response);
exit();
?>