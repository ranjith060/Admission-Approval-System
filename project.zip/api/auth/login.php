<?php
// 1. Clean Output Buffer (Prevents Network Error)
ob_start();
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 0); // Hide raw errors

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");

$response = [];

try {
    // 2. Database Connection
    if (!file_exists('../../config/db.php')) {
        throw new Exception("DB Config file missing.");
    }
    require_once '../../config/db.php';

    // 3. Get Input
    $input = file_get_contents("php://input");
    $data = json_decode($input);

    if (empty($data->email) || empty($data->password)) {
        throw new Exception("Please enter Email and Password.");
    }

    // 4. Check User
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$data->email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        throw new Exception("User not found! Please Register first.");
    }

    // 5. Verify Password
    if (password_verify($data->password, $user['password_hash'])) {
        
        // Login Success - Set Session
        $_SESSION['user_uid']  = $user['user_uid'];
        $_SESSION['username']  = $user['username'];
        $_SESSION['role_code'] = $user['role_code'];
        $_SESSION['email']     = $user['email'];
        $_SESSION['mobile_no'] = $user['mobile_no'];

        // Determine Redirect URL
        $redirect = ($user['role_code'] == 'ADMIN') ? 'admin/dashboard.php' : 'student/dashboard.php';

        $response = [
            "status" => "success", 
            "message" => "Login Successful! Redirecting...", 
            "redirect" => $redirect
        ];
    } else {
        throw new Exception("Incorrect Password!");
    }

} catch (Exception $e) {
    $response = ["status" => "error", "message" => $e->getMessage()];
}

// 6. Output Clean JSON
ob_clean();
echo json_encode($response);
exit();
?>