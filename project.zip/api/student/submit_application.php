<?php
session_start();
ob_clean(); // Clean output buffer to prevent stray chars
header("Content-Type: application/json");

require_once '../../config/db.php';
require_once '../../includes/functions.php';

// Disable raw error display to avoid JSON parsing error in frontend
error_reporting(E_ALL);
ini_set('display_errors', 0); 

if (!isset($_SESSION['user_uid'])) {
    echo json_encode(["status" => "error", "message" => "Session Expired. Please Login Again."]);
    exit();
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Invalid Request Method");
    }

    $user_uid = $_SESSION['user_uid'];
    $role = $_SESSION['role_code'] ?? 'STUDENT';

    // 1. Generate Application Number
    $app_no = generateApplicationID($conn);

    $conn->beginTransaction();

    // 2. Prepare Main Application Data (Key => Value)
    // NOTE: Order doesn't matter here, keys map to columns automatically
    $app_data = [
        'application_no'        => $app_no,
        'user_uid'              => $user_uid,
        'course_code'           => $_POST['course_code'] ?? '',
        'admission_category'    => $_POST['admission_type'] ?? '',
        'quota_type'            => ($role == 'ADMIN') ? ($_POST['quota'] ?? 'GOVT') : 'GOVT',
        'app_status'            => 'Submitted',
        'calculated_percentage' => floatval(str_replace('%', '', $_POST['percentage'] ?? 0)),
        'student_name'          => $_POST['student_name'] ?? '',
        'dob'                   => $_POST['dob'] ?? null,
        'age'                   => $_POST['age'] ?? 0,
        'gender'                => $_POST['gender'] ?? '',
        'blood_group'           => $_POST['blood_group'] ?? '',
        'community_class'       => $_POST['community'] ?? '',
        'caste_name'            => $_POST['caste_name'] ?? '',
        'religion'              => $_POST['religion'] ?? '',
        'mother_tongue'         => $_POST['mother_tongue'] ?? '',
        'nationality'           => 'Indian',
        'aadhar_no'             => $_POST['aadhar_no'] ?? '',
        'emis_no'               => $_POST['emis_no'] ?? '',
        'umis_no'               => NULL, // Admin only
        'address_communication' => $_POST['address_communication'] ?? '',
        'address_permanent'     => $_POST['address_communication'] ?? '', // Copy comm address
        'district'              => '', // Not in form
        'pincode'               => '', // Not in form
        'transport_required'    => $_POST['transport_required'] ?? 'No',
        'transport_place_from'  => $_POST['transport_place'] ?? '',
        'hostel_required'       => $_POST['hostel_required'] ?? 'No',
        'bank_name'             => $_POST['bank_name'] ?? '',
        'bank_branch'           => $_POST['bank_branch'] ?? '',
        'bank_account_no'       => $_POST['account_no'] ?? '',
        'ifsc_code'             => $_POST['ifsc_code'] ?? '',
        // Nullable fields
        'prev_college_name'     => NULL,
        'discontinuation_reason'=> NULL,
        'transfer_reason'       => NULL,
        'old_reg_no'            => NULL,
        'attendance_percentage' => NULL,
        'admin_remarks'         => NULL
    ];

    // DYNAMIC INSERT QUERY GENERATOR (No more counting errors!)
    $columns = implode(", ", array_keys($app_data));
    $placeholders = implode(", ", array_fill(0, count($app_data), "?"));
    $values = array_values($app_data);

    $stmt = $conn->prepare("INSERT INTO admission_applications ($columns) VALUES ($placeholders)");
    $stmt->execute($values);

    // 3. Insert References
    if (!empty($_POST['reference_type']) && $_POST['reference_type'] != 'Direct') {
        $ref_sql = "INSERT INTO admission_references (
            application_no, reference_type, referrer_name, ref_student_year, ref_student_dept, 
            ref_alumni_passed_year, ref_faculty_designation, ref_consultancy_contact
        ) VALUES (?,?,?,?,?,?,?,?)";
        
        $ref_stmt = $conn->prepare($ref_sql);
        
        $ref_type = $_POST['reference_type'];
        $ref_name = $_POST['ref_name'] ?? NULL;
        $ref_year = ($ref_type == 'Student') ? ($_POST['ref_year'] ?? NULL) : NULL;
        $ref_dept = ($ref_type == 'Student' || $ref_type == 'Faculty') ? ($_POST['ref_department'] ?? NULL) : NULL;
        $ref_alum_year = ($ref_type == 'Alumni') ? ($_POST['ref_year'] ?? NULL) : NULL;
        $ref_desig = ($ref_type == 'Faculty') ? ($_POST['ref_designation'] ?? NULL) : NULL;
        $ref_contact = ($ref_type == 'Consultancy') ? ($_POST['ref_contact'] ?? NULL) : NULL;

        $ref_stmt->execute([
            $app_no, $ref_type, $ref_name, $ref_year, $ref_dept, $ref_alum_year, $ref_desig, $ref_contact
        ]);
    }

    // 4. Insert Marks
    $marks_json = $_POST['marks_json'] ?? '[]';
    $marks_data = json_decode($marks_json, true);
    
    if ($marks_data && is_array($marks_data)) {
        $mark_stmt = $conn->prepare("INSERT INTO admission_marks (application_no, qualification, subject_name, marks_obtained, max_marks) VALUES (?,?,?,?,?)");
        $qual = $_POST['qualification'] ?? 'SSLC';
        
        foreach ($marks_data as $mark) {
            $mark_stmt->execute([
                $app_no, 
                $qual, 
                $mark['subject'], 
                $mark['obtained'], 
                $mark['max']
            ]);
        }
    }

    // 5. Insert Family Details
    $fam_stmt = $conn->prepare("INSERT INTO admission_family_details (
        application_no, father_name, father_mobile, father_occupation, father_income,
        mother_name, mother_mobile, mother_occupation, mother_income,
        guardian_address
    ) VALUES (?,?,?,?,?,?,?,?,?,?)");
    
    $fam_stmt->execute([
        $app_no, 
        $_POST['father_name'] ?? '', 
        $_POST['father_mobile'] ?? '', 
        $_POST['father_occupation'] ?? '', 
        $_POST['father_income'] ?? 0,
        $_POST['mother_name'] ?? '', 
        $_POST['mother_mobile'] ?? '', 
        $_POST['mother_occupation'] ?? '', 
        $_POST['mother_income'] ?? 0,
        $_POST['father_address'] ?? '' // Address
    ]);

    // 6. Insert Academic History
    $acad_stmt = $conn->prepare("INSERT INTO admission_academic_history (
        application_no, qualification, institution_name, institution_place, reg_no, year_of_passing, medium_of_instruction
    ) VALUES (?,?,?,?,?,?,?)");

    $acad_stmt->execute([
        $app_no,
        $_POST['qualification'] ?? 'SSLC',
        $_POST['school_name'] ?? '',
        $_POST['school_place'] ?? '',
        $_POST['school_reg_no'] ?? '',
        $_POST['year_of_passing'] ?? date('Y'),
        $_POST['medium_of_instruction'] ?? ''
    ]);

    $conn->commit();
    echo json_encode(["status" => "success", "message" => "Application Submitted Successfully! App No: " . $app_no]);

} catch (Exception $e) {
    if(isset($conn) && $conn->inTransaction()) $conn->rollBack();
    // Use error log for server side debugging, simpler message for client
    error_log("Submission Error: " . $e->getMessage());
    echo json_encode(["status" => "error", "message" => "Submission Failed: " . $e->getMessage()]);
}
?>