<?php
session_start();
header("Content-Type: application/json");
require_once '../../config/db.php';
require_once '../../includes/functions.php';

// Check Login
if (!isset($_SESSION['user_uid'])) {
    echo json_encode(["status" => "error", "message" => "Unauthorized Access"]);
    exit();
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Invalid Request");
    }

    $app_no = $_POST['application_no'];
    $doc_type = $_POST['doc_type'];
    
    // Validate File Input
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception("Please select a valid file to upload.");
    }

    $file = $_FILES['file'];
    $allowed_types = ['image/jpeg', 'image/png', 'application/pdf'];
    $max_size = 2 * 1024 * 1024; // 2MB

    // 1. Validation
    if (!in_array($file['type'], $allowed_types)) {
        throw new Exception("Invalid file type. Only JPG, PNG, PDF allowed.");
    }
    if ($file['size'] > $max_size) {
        throw new Exception("File size too large. Max 2MB allowed.");
    }

    // 2. Prepare File Name (APPNO_DOCTYPE.ext)
    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $new_filename = $app_no . "_" . $doc_type . "." . $ext;
    $upload_dir = "../../uploads/";
    
    // Create folder if not exists
    if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);

    $destination = $upload_dir . $new_filename;

    // 3. Move File
    if (move_uploaded_file($file['tmp_name'], $destination)) {
        
        // 4. Update Database (Delete old entry if exists, then insert)
        $conn->prepare("DELETE FROM admission_documents WHERE application_no=? AND doc_type=?")->execute([$app_no, $doc_type]);
        
        $sql = "INSERT INTO admission_documents (application_no, doc_type, file_path, verification_status) VALUES (?, ?, ?, 'Pending')";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$app_no, $doc_type, $new_filename]);

        echo json_encode(["status" => "success", "message" => "File Uploaded Successfully!"]);
    } else {
        throw new Exception("Failed to save file.");
    }

} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
?>