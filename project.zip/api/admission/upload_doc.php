<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");

require_once '../../config/db.php';

// 1. Check Application Number
if (empty($_POST['application_no'])) {
    echo json_encode(["status" => "error", "message" => "Application Number Missing"]);
    exit();
}

$app_no = $_POST['application_no'];
$target_dir = "../../uploads/";
$allowed_exts = ['jpg', 'jpeg', 'png', 'pdf'];

if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);

// 2. Mapping
$doc_map = [
    'photo_file'     => 'PHOTO',
    'aadhar_file'    => 'AADHAR',
    'community_file' => 'COMMUNITY',
    'income_file'    => 'INCOME',
    'bank_file'      => 'BANK_PASSBOOK',
    'sslc_file'      => 'SSLC_MARK',
    'hsc_file'       => 'HSC_MARK',
    'tc_file'        => 'TC'
];

$uploaded_files = [];
$errors = [];

try {
    foreach ($doc_map as $input_name => $db_doc_type) {
        
        if (isset($_FILES[$input_name]) && $_FILES[$input_name]['error'] == 0) {
            
            $file = $_FILES[$input_name];
            $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

            if (!in_array($file_ext, $allowed_exts)) {
                $errors[] = "$db_doc_type: Invalid Format";
                continue;
            }

            $new_filename = $app_no . "_" . $db_doc_type . "." . $file_ext;
            $target_file = $target_dir . $new_filename;

            if (move_uploaded_file($file['tmp_name'], $target_file)) {
                
                $db_path = "uploads/" . $new_filename;
                
                // CHECK IF EXISTS (Using Composite Key)
                // FIX: Removed 'doc_id' from SELECT
                $check = $conn->prepare("SELECT file_path FROM admission_documents WHERE application_no=? AND doc_type=?");
                $check->execute([$app_no, $db_doc_type]);
                
                if($check->rowCount() > 0) {
                    // UPDATE
                    $sql = "UPDATE admission_documents SET file_path=?, uploaded_at=NOW(), verification_status='Pending' 
                            WHERE application_no=? AND doc_type=?";
                    $stmt = $conn->prepare($sql);
                    $stmt->execute([$db_path, $app_no, $db_doc_type]);
                } else {
                    // INSERT
                    // FIX: No 'doc_id' in Insert
                    $sql = "INSERT INTO admission_documents (application_no, doc_type, file_path, verification_status) 
                            VALUES (?, ?, ?, 'Pending')";
                    $stmt = $conn->prepare($sql);
                    $stmt->execute([$app_no, $db_doc_type, $db_path]);
                }

                $uploaded_files[] = $db_doc_type;
            } else {
                $errors[] = "$db_doc_type: Save Failed";
            }
        }
    }

    echo json_encode([
        "status" => "success",
        "message" => "Upload Process Completed",
        "uploaded" => $uploaded_files,
        "errors" => $errors
    ]);

} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => "DB Error: " . $e->getMessage()]);
}
?>