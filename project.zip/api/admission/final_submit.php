<?php
require_once '../../config/db.php';
header('Content-Type: application/json');

$app_no = $_POST['app_no'];

try {
    // Only update if status is Draft
    $stmt = $conn->prepare("UPDATE admission_applications SET app_status = 'Submitted' WHERE application_no = ? AND app_status = 'Draft'");
    $stmt->execute([$app_no]);

    if ($stmt->rowCount() > 0) {
        echo json_encode(["status" => "success"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Already Submitted or Invalid ID"]);
    }
} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
?>