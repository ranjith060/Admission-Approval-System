<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");

require_once '../../config/db.php';
require_once '../../includes/functions.php';

$data = json_decode(file_get_contents("php://input"));

// Basic Validation
if (empty($data->user_uid) || empty($data->course_code_pref)) {
    echo json_encode(["status" => "error", "message" => "Missing User ID or Course Preference"]);
    exit();
}

try {
    $conn->beginTransaction();

    // 1. Check if Application Exists for User
    $check_stmt = $conn->prepare("SELECT application_no FROM admission_applications WHERE user_uid = ?");
    $check_stmt->execute([$data->user_uid]);
    $existing_app = $check_stmt->fetch(PDO::FETCH_ASSOC);

    if ($existing_app) {
        // UPDATE MODE
        $app_no = $existing_app['application_no'];
        
        // Update Main Table
        $sql_main = "UPDATE admission_applications SET 
            course_code_pref=?, admission_category=?, quota_type=?, student_name=?, dob=?, gender=?, 
            community_class=?, caste_name=?, religion=?, mother_tongue=?, aadhar_no=?, emis_no=?, umis_no=?,
            address_communication=?, address_permanent=?, district=?, pincode=?, 
            transport_required=?, transport_place_from=?, hostel_required=?,
            bank_name=?, bank_branch=?, bank_account_no=?, ifsc_code=?,
            calculated_percentage=?, app_status='Submitted'
            WHERE application_no=?";
        
        $stmt = $conn->prepare($sql_main);
        $stmt->execute([
            $data->course_code_pref, $data->admission_category, $data->quota_type,
            $data->student_name, $data->dob, $data->gender,
            $data->community, $data->caste, $data->religion, $data->mother_tongue,
            $data->aadhar, $data->emis, $data->umis,
            $data->address_comm, $data->address_perm, $data->district, $data->pincode,
            $data->transport, $data->boarding, $data->hostel,
            $data->bank_name, $data->bank_branch, $data->bank_acc, $data->bank_ifsc,
            $data->calculated_percentage, $app_no
        ]);

        // Clear Child Tables (To avoid Composite Key Duplicates on Insert)
        $conn->prepare("DELETE FROM admission_family WHERE application_no = ?")->execute([$app_no]);
        $conn->prepare("DELETE FROM admission_marks WHERE application_no = ?")->execute([$app_no]);
        // Note: We don't delete documents or references here usually, unless needed.

    } else {
        // INSERT MODE (New Application)
        $app_no = generateApplicationID($conn);

        $sql_main = "INSERT INTO admission_applications 
        (application_no, user_uid, course_code_pref, admission_category, quota_type, student_name, dob, gender, 
         community_class, caste_name, religion, mother_tongue, aadhar_no, emis_no, umis_no,
         address_communication, address_permanent, district, pincode, 
         transport_required, transport_place_from, hostel_required,
         bank_name, bank_branch, bank_account_no, ifsc_code,
         calculated_percentage, app_status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Submitted')";

        $stmt = $conn->prepare($sql_main);
        $stmt->execute([
            $app_no, $data->user_uid, $data->course_code_pref, $data->admission_category, $data->quota_type,
            $data->student_name, $data->dob, $data->gender,
            $data->community, $data->caste, $data->religion, $data->mother_tongue,
            $data->aadhar, $data->emis, $data->umis,
            $data->address_comm, $data->address_perm, $data->district, $data->pincode,
            $data->transport, $data->boarding, $data->hostel,
            $data->bank_name, $data->bank_branch, $data->bank_acc, $data->bank_ifsc,
            $data->calculated_percentage
        ]);
    }

    // 2. Insert Family Details (Re-inserting logic)
    // Note: Table name changed to 'admission_family' based on new schema
    $sql_family = "INSERT INTO admission_family 
                   (application_no, relation_type, name, mobile_no, occupation, annual_income) 
                   VALUES (?, ?, ?, ?, ?, ?)";
    $stmt_fam = $conn->prepare($sql_family);
    
    // Father
    $stmt_fam->execute([$app_no, 'Father', $data->father_name, $data->father_mobile, $data->father_occ, $data->father_income]);
    // Mother
    $stmt_fam->execute([$app_no, 'Mother', $data->mother_name, $data->mother_mobile ?? '', $data->mother_occ ?? '', $data->mother_income ?? 0]);

    // 3. Insert Marks
    if (!empty($data->marks)) {
        $sql_marks = "INSERT INTO admission_marks (application_no, subject_name, marks_obtained, max_marks) VALUES (?, ?, ?, ?)";
        $stmt_m = $conn->prepare($sql_marks);
        
        foreach ($data->marks as $mark) {
            $stmt_m->execute([$app_no, $mark->subject, $mark->obtained, $mark->max]);
        }
    }

    $conn->commit();

    echo json_encode([
        "status" => "success", 
        "message" => "Application Saved Successfully!",
        "application_no" => $app_no
    ]);

} catch (Exception $e) {
    if ($conn->inTransaction()) $conn->rollBack();
    echo json_encode(["status" => "error", "message" => "Submission Failed: " . $e->getMessage()]);
}
?>