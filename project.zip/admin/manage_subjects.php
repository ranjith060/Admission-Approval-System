<?php
require_once '../includes/auth_session.php';
require_once '../config/db.php';
checkLogin('ADMIN');

// Fetch all subjects joined with course details for better display
$subjects = $conn->query("SELECT s.*, c.course_short 
                          FROM subjects s 
                          JOIN course_master c ON s.course_code = c.course_code 
                          ORDER BY s.course_code, s.semester_number, s.subject_code");

// Fetch courses for the filter dropdown
$courses = $conn->query("SELECT * FROM course_master WHERE status='Active'");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Manage Subjects | NLPTC ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

    <?php include 'includes/sidebar.php'; ?>

    <div class="content">
        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold text-primary"><i class="fas fa-book"></i> Manage Subjects</h2>
            <button class="btn btn-primary" onclick="openAddModal()">
                <i class="fas fa-plus-circle me-2"></i> Add New Subject
            </button>
        </div>

        <div class="card shadow-sm mb-4">
            <div class="card-body bg-light">
                <div class="row g-3">
                    <div class="col-md-4">
                        <input type="text" id="searchBox" class="form-control" placeholder="Search by Subject Name or Code...">
                    </div>
                    <div class="col-md-3">
                        <select id="filterCourse" class="form-select">
                            <option value="">All Courses</option>
                            <?php while($c = $courses->fetch(PDO::FETCH_ASSOC)): ?>
                                <option value="<?= $c['course_short'] ?>"><?= $c['course_name'] ?> (<?= $c['course_short'] ?>)</option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select id="filterSem" class="form-select">
                            <option value="">All Semesters</option>
                            <?php for($i=1; $i<=8; $i++) echo "<option value='$i'>Semester $i</option>"; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-secondary w-100" onclick="resetFilters()">Reset</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="card shadow-sm">
            <div class="card-body p-0">
                <div class="table-responsive" style="max-height: 600px; overflow-y: auto;">
                    <table class="table table-hover align-middle mb-0" id="subjectsTable">
                        <thead class="table-dark text-center sticky-top">
                            <tr>
                                <th>Code</th>
                                <th>Subject Name</th>
                                <th>Dept</th>
                                <th>Sem</th>
                                <th>Type</th>
                                <th>Credits</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = $subjects->fetch(PDO::FETCH_ASSOC)): ?>
                            <tr data-course="<?= $row['course_short'] ?>" data-sem="<?= $row['semester_number'] ?>">
                                <td class="fw-bold text-secondary"><?= $row['subject_code'] ?></td>
                                <td><?= $row['subject_name'] ?></td>
                                <td><span class="badge bg-info text-dark"><?= $row['course_short'] ?></span></td>
                                <td class="text-center"><span class="badge bg-secondary"><?= $row['semester_number'] ?></span></td>
                                <td><?= $row['subject_type'] ?></td>
                                <td class="text-center fw-bold"><?= $row['credits'] ?></td>
                                <td class="text-center">
                                    <div class="btn-group" role="group">
                                        <button class="btn btn-sm btn-outline-info" onclick="viewSubject('<?= $row['subject_code'] ?>')" title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-warning" onclick="editSubject('<?= $row['subject_code'] ?>')" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger" onclick="deleteSubject('<?= $row['subject_code'] ?>')" title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    <div id="noRecords" class="text-center p-4 text-muted d-none">No subjects found matching criteria.</div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="subjectModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalTitle">Add Subject</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="subjectForm">
                        <input type="hidden" name="action" id="formAction" value="add">
                        
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label fw-bold">Subject Code</label>
                                <input type="text" name="subject_code" id="subject_code" class="form-control" required>
                            </div>
                            <div class="col-md-8">
                                <label class="form-label fw-bold">Subject Name</label>
                                <input type="text" name="subject_name" id="subject_name" class="form-control" required>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label">Course Code</label>
                                <select name="course_code" id="course_code" class="form-select" required>
                                    <?php 
                                    // Reset pointer to beginning of courses result set
                                    $courses->execute(); 
                                    while($c = $courses->fetch(PDO::FETCH_ASSOC)) {
                                        echo "<option value='{$c['course_code']}'>{$c['course_name']} ({$c['course_short']})</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Semester</label>
                                <select name="semester_number" id="semester_number" class="form-select">
                                    <?php for($i=1; $i<=8; $i++) echo "<option value='$i'>Sem $i</option>"; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Regulation</label>
                                <input type="text" name="regulation" id="regulation" class="form-control" value="R2023">
                            </div>

                            <div class="col-md-4">
                                <label class="form-label">Subject Type</label>
                                <select name="subject_type" id="subject_type" class="form-select">
                                    <option>Theory</option>
                                    <option>Practicum</option>
                                    <option>Practical/Lab</option>
                                    <option>Elective</option>
                                    <option>Project/Internship</option>
                                    <option>Advanced Skill Certification</option>
                                    <option>Integrated Learning Experience</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">End Exam Type</label>
                                <select name="end_exam" id="end_exam" class="form-select">
                                    <option>Theory</option>
                                    <option>Practical</option>
                                    <option>Project</option>
                                    <option>NA</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Elective Type</label>
                                <select name="elective_type" id="elective_type" class="form-select">
                                    <option>None</option>
                                    <option>Elective 1</option>
                                    <option>Elective 2</option>
                                    <option>Elective 3 (Pathway)</option>
                                    <option>Elective 4 (Specialisation)</option>
                                </select>
                            </div>

                            <div class="col-md-3"><label class="form-label">Lecture (L)</label><input type="number" name="L" id="L" class="form-control" value="0"></div>
                            <div class="col-md-3"><label class="form-label">Tutorial (T)</label><input type="number" name="T" id="T" class="form-control" value="0"></div>
                            <div class="col-md-3"><label class="form-label">Practical (P)</label><input type="number" name="P" id="P" class="form-control" value="0"></div>
                            <div class="col-md-3"><label class="form-label">Credits</label><input type="number" name="credits" id="credits" class="form-control" value="0"></div>

                            <div class="col-md-4"><label class="form-label">Total Periods</label><input type="number" name="periods" id="periods" class="form-control" value="0"></div>
                            <div class="col-md-4"><label class="form-label">Min Pass %</label><input type="text" name="min_pass_percentage" id="min_pass_percentage" class="form-control" value="35.00"></div>
                            <div class="col-md-4"><label class="form-label">Max Mark</label><input type="text" name="max_percentage" id="max_percentage" class="form-control" value="100.00"></div>
                        </div>

                        <div class="mt-4 text-end">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success">Save Subject</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="viewModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h5 class="modal-title">Subject Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <table class="table table-bordered">
                        <tbody>
                            <tr><th width="40%">Code</th><td id="v_code"></td></tr>
                            <tr><th>Name</th><td id="v_name"></td></tr>
                            <tr><th>Course</th><td id="v_course"></td></tr>
                            <tr><th>Semester</th><td id="v_sem"></td></tr>
                            <tr><th>Credits</th><td id="v_credits"></td></tr>
                            <tr><th>L-T-P</th><td id="v_ltp"></td></tr>
                            <tr><th>Type</th><td id="v_type"></td></tr>
                            <tr><th>Regulation</th><td id="v_reg"></td></tr>
                            <tr><th>Marks (Min/Max)</th><td id="v_marks"></td></tr>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const subjectModal = new bootstrap.Modal(document.getElementById('subjectModal'));
        const viewModal = new bootstrap.Modal(document.getElementById('viewModal'));

        // --- FILTERING LOGIC ---
        const searchBox = document.getElementById('searchBox');
        const filterCourse = document.getElementById('filterCourse');
        const filterSem = document.getElementById('filterSem');
        const tableRows = document.querySelectorAll('#subjectsTable tbody tr');
        const noRecords = document.getElementById('noRecords');

        function filterTable() {
            const searchText = searchBox.value.toLowerCase();
            const courseVal = filterCourse.value;
            const semVal = filterSem.value;
            let visibleCount = 0;

            tableRows.forEach(row => {
                const textMatch = row.innerText.toLowerCase().includes(searchText);
                const courseMatch = courseVal === "" || row.dataset.course === courseVal;
                const semMatch = semVal === "" || row.dataset.sem === semVal;

                if (textMatch && courseMatch && semMatch) {
                    row.style.display = "";
                    visibleCount++;
                } else {
                    row.style.display = "none";
                }
            });

            noRecords.classList.toggle('d-none', visibleCount > 0);
        }

        searchBox.addEventListener('input', filterTable);
        filterCourse.addEventListener('change', filterTable);
        filterSem.addEventListener('change', filterTable);

        function resetFilters() {
            searchBox.value = "";
            filterCourse.value = "";
            filterSem.value = "";
            filterTable();
        }

        // --- CRUD OPERATIONS ---

        function openAddModal() {
            document.getElementById('subjectForm').reset();
            document.getElementById('formAction').value = 'add';
            document.getElementById('subject_code').readOnly = false;
            document.getElementById('modalTitle').innerText = 'Add New Subject';
            subjectModal.show();
        }

        async function viewSubject(code) {
            const data = await fetchSubjectData(code);
            document.getElementById('v_code').innerText = data.subject_code;
            document.getElementById('v_name').innerText = data.subject_name;
            document.getElementById('v_course').innerText = data.course_code; // Or fetch course name
            document.getElementById('v_sem').innerText = data.semester_number;
            document.getElementById('v_credits').innerText = data.credits;
            document.getElementById('v_ltp').innerText = `${data.L} - ${data.T} - ${data.P}`;
            document.getElementById('v_type').innerText = data.subject_type + (data.elective_type !== 'None' ? ` (${data.elective_type})` : '');
            document.getElementById('v_reg').innerText = data.regulation;
            document.getElementById('v_marks').innerText = `${Math.round(data.min_pass_percentage)} / ${Math.round(data.max_percentage)}`;
            viewModal.show();
        }

        async function editSubject(code) {
            const data = await fetchSubjectData(code);
            
            // Fill Form
            for(const key in data) {
                if(document.getElementById(key)) document.getElementById(key).value = data[key];
            }

            document.getElementById('formAction').value = 'update';
            document.getElementById('subject_code').readOnly = true; // PK
            document.getElementById('modalTitle').innerText = 'Edit Subject';
            subjectModal.show();
        }

        async function fetchSubjectData(code) {
            const formData = new FormData();
            formData.append('action', 'fetch_single');
            formData.append('subject_code', code);

            const res = await fetch('../api/admin/manage_subjects_api.php', { method: 'POST', body: formData });
            return await res.json();
        }

        async function deleteSubject(code) {
            if(!confirm('Are you sure you want to delete this subject?')) return;

            const formData = new FormData();
            formData.append('action', 'delete');
            formData.append('subject_code', code);

            const res = await fetch('../api/admin/manage_subjects_api.php', { method: 'POST', body: formData });
            const result = await res.json();
            alert(result.message);
            location.reload();
        }

        document.getElementById('subjectForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            
            const res = await fetch('../api/admin/manage_subjects_api.php', { method: 'POST', body: formData });
            const result = await res.json();
            
            if(result.status === 'success') {
                alert(result.message);
                location.reload();
            } else {
                alert('Error: ' + result.message);
            }
        });
    </script>
</body>
</html>