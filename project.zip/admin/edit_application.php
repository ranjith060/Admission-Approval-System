<?php
require_once '../includes/auth_session.php';
require_once '../config/db.php';
checkLogin('ADMIN');

$app_no = $_GET['app_no'];
$msg = "";

// UPDATE LOGIC
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['student_name'];
    $comm = $_POST['community'];
    $marks = $_POST['percentage'];
    
    $stmt = $conn->prepare("UPDATE admission_applications SET student_name=?, community_class=?, calculated_percentage=? WHERE application_no=?");
    if($stmt->execute([$name, $comm, $marks, $app_no])) {
        $msg = "<div class='alert alert-success'>Application Updated Successfully! <a href='applications.php'>Go Back</a></div>";
    }
}

// FETCH DATA
$stmt = $conn->prepare("SELECT * FROM admission_applications WHERE application_no=?");
$stmt->execute([$app_no]);
$app = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit Application | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-5 bg-light">
    <div class="card shadow col-md-8 mx-auto">
        <div class="card-header bg-warning">
            <h5>Edit Application: <?= $app_no ?></h5>
        </div>
        <div class="card-body">
            <?= $msg ?>
            <form method="POST">
                <div class="mb-3">
                    <label>Student Name</label>
                    <input type="text" name="student_name" class="form-control" value="<?= $app['student_name'] ?>" required>
                </div>
                <div class="mb-3">
                    <label>Community</label>
                    <select name="community" class="form-select">
                        <option value="<?= $app['community_class'] ?>" selected><?= $app['community_class'] ?> (Current)</option>
                        <option value="OC">OC</option><option value="BC">BC</option><option value="MBC">MBC</option><option value="SC">SC</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label>Calculated Percentage</label>
                    <input type="text" name="percentage" class="form-control" value="<?= $app['calculated_percentage'] ?>">
                </div>
                <button type="submit" class="btn btn-primary">Update Details</button>
                <a href="applications.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</body>
</html>