<?php
require_once '../includes/auth_session.php';
require_once '../config/db.php';
checkLogin('ADMIN');

// Handle actions (Approve/Reject)
if (isset($_GET['action']) && isset($_GET['id'])) {
    $status = ($_GET['action'] == 'approve') ? 'Approved' : 'Rejected';
    $stmt = $conn->prepare("UPDATE admission_applications SET app_status = ? WHERE application_no = ?");
    $stmt->execute([$status, $_GET['id']]);
    header("Location: applications.php");
    exit();
}

// Fetch Applications
// FIX: Changed 'a.quota' to 'a.quota_type' based on your SQL file
$sql = "SELECT a.application_no, a.user_uid, a.course_code, a.quota_type, a.app_status, 
               u.username, u.email, u.mobile_no, 
               c.course_short 
        FROM admission_applications a
        JOIN users u ON a.user_uid = u.user_uid
        JOIN course_master c ON a.course_code = c.course_code
        ORDER BY a.application_no DESC";

try {
    $stmt = $conn->query($sql);
} catch (PDOException $e) {
    die("<div class='alert alert-danger'>Database Error: " . $e->getMessage() . "</div>");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Applications | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f4f6f9; }
        .content { margin-left: 250px; padding: 30px; transition: 0.3s; }
        @media (max-width: 768px) { .content { margin-left: 0; } }
    </style>
</head>
<body>

    <?php include 'includes/sidebar.php'; ?>

    <div class="content">
        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Student Applications</h2>
            <a href="dashboard.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i> Back to Dashboard
            </a>
        </div>

        <div class="card shadow-sm">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th>App No</th>
                                <th>Student Name</th>
                                <th>Course</th>
                                <th>Mobile</th>
                                <th>Quota</th> <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
                            <tr>
                                <td class="fw-bold"><?= $row['application_no'] ?></td>
                                <td>
                                    <div class="fw-bold"><?= htmlspecialchars($row['username']) ?></div>
                                    <small class="text-muted"><?= htmlspecialchars($row['email']) ?></small>
                                </td>
                                <td><span class="badge bg-info text-dark"><?= $row['course_short'] ?></span></td>
                                <td><?= $row['mobile_no'] ?></td>
                                
                                <td>
                                    <?php if($row['quota_type'] == 'GOVT'): ?>
                                        <span class="badge bg-primary">Govt</span>
                                    <?php elseif($row['quota_type'] == 'MGMT'): ?>
                                        <span class="badge bg-warning text-dark">Mgmt</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Pending</span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <?php 
                                        $statusColor = 'secondary';
                                        if($row['app_status'] == 'Submitted') $statusColor = 'warning text-dark';
                                        if($row['app_status'] == 'Verified') $statusColor = 'info text-dark';
                                        if($row['app_status'] == 'Approved') $statusColor = 'success';
                                        if($row['app_status'] == 'Rejected') $statusColor = 'danger';
                                    ?>
                                    <span class="badge bg-<?= $statusColor ?>"><?= $row['app_status'] ?></span>
                                </td>

                                <td>
                                    <a href="view_application.php?id=<?= $row['application_no'] ?>" class="btn btn-sm btn-primary" title="View Details">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</body>
</html>