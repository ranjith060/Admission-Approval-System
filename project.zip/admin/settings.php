<?php
require_once '../includes/auth_session.php';
require_once '../config/db.php';
checkLogin('ADMIN');

// Handle Actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // 1. Add Academic Year
    if (isset($_POST['add_year'])) {
        $code = filter_input(INPUT_POST, 'ay_code', FILTER_SANITIZE_STRING); // Validation
        $short = filter_input(INPUT_POST, 'ay_short', FILTER_SANITIZE_STRING);
        
        if($code && $short) {
            $stmt = $conn->prepare("INSERT INTO academic_years (ay_code, ay_short_code) VALUES (?, ?)");
            $stmt->execute([$code, $short]);
            $msg = "Academic Year Added!";
        }
    }
    // 2. Set Active Year
    elseif (isset($_POST['set_active'])) {
        $conn->query("UPDATE academic_years SET is_active='No'"); // Reset all
        $stmt = $conn->prepare("UPDATE academic_years SET is_active='Yes' WHERE ay_code = ?");
        $stmt->execute([$_POST['active_year']]);
        $msg = "Active Year Updated!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>System Settings | NLPTC ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

    <?php include 'includes/sidebar.php'; ?>

    <div class="content" style="padding: 30px;">
        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold text-primary"><i class="fas fa-cogs"></i> System Settings</h2>
            <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
        </div>

        <?php if(isset($msg)): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?= $msg ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-6">
                <div class="card shadow-sm mb-4 border-0">
                    <div class="card-header bg-primary text-white fw-bold">
                        <i class="fas fa-calendar-check me-2"></i> Academic Year Configuration
                    </div>
                    <div class="card-body">
                        <form method="POST" class="mb-4">
                            <label class="form-label fw-bold">Set Active Academic Year</label>
                            <div class="input-group">
                                <select name="active_year" class="form-select">
                                    <?php
                                    $years = $conn->query("SELECT * FROM academic_years ORDER BY ay_code DESC");
                                    foreach($years as $y) {
                                        $sel = ($y['is_active'] == 'Yes') ? 'selected' : '';
                                        echo "<option value='{$y['ay_code']}' $sel>{$y['ay_code']} ({$y['ay_short_code']})</option>";
                                    }
                                    ?>
                                </select>
                                <button type="submit" name="set_active" class="btn btn-success">Save</button>
                            </div>
                        </form>

                        <hr>
                        <h5 class="fw-bold text-secondary">Add New Year</h5>
                        <form method="POST">
                            <div class="row g-2">
                                <div class="col-6">
                                    <input type="text" name="ay_code" class="form-control" placeholder="2026-2027" required pattern="\d{4}-\d{4}">
                                </div>
                                <div class="col-4">
                                    <input type="text" name="ay_short" class="form-control" placeholder="2627" required pattern="\d{4}">
                                </div>
                                <div class="col-2">
                                    <button type="submit" name="add_year" class="btn btn-primary w-100"><i class="fas fa-plus"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-dark text-white fw-bold">
                        <i class="fas fa-database me-2"></i> Backup & Recovery
                    </div>
                    <div class="card-body text-center py-4">
                        <p class="text-muted mb-4">Recover accidentally deleted courses or faculty members from the recycle bin.</p>
                        <a href="recycle_bin.php" class="btn btn-warning w-75 py-2 fw-bold">
                            <i class="fas fa-trash-restore me-2"></i> Open Recycle Bin
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>