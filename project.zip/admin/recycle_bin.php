    <?php
require_once '../includes/auth_session.php';
require_once '../config/db.php';
checkLogin('ADMIN');

if (isset($_POST['restore'])) {
    $table = $_POST['type'] == 'course' ? 'course_master' : 'faculty_master';
    $id_col = $_POST['type'] == 'course' ? 'course_code' : 'faculty_id';
    
    $stmt = $conn->prepare("UPDATE $table SET is_deleted = 0 WHERE $id_col = ?");
    $stmt->execute([$_POST['id']]);
    $msg = "Item Restored Successfully!";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Recycle Bin | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
    <h3>Recycle Bin (Recovery)</h3>
    <?php if(isset($msg)) echo "<div class='alert alert-success'>$msg</div>"; ?>
    
    <div class="row">
        <div class="col-md-6">
            <h5>Deleted Courses</h5>
            <ul class="list-group">
                <?php
                $del_courses = $conn->query("SELECT * FROM course_master WHERE is_deleted = 1");
                foreach($del_courses as $c) {
                    echo "<li class='list-group-item d-flex justify-content-between'>
                            {$c['course_name']}
                            <form method='POST'>
                                <input type='hidden' name='type' value='course'>
                                <input type='hidden' name='id' value='{$c['course_code']}'>
                                <button type='submit' name='restore' class='btn btn-sm btn-success'>Restore</button>
                            </form>
                          </li>";
                }
                ?>
            </ul>
        </div>
    </div>
</body>
</html>