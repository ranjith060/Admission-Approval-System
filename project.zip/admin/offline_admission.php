<?php
require_once '../includes/auth_session.php';
require_once '../config/db.php';
checkLogin('ADMIN');

// Active Courses for Dropdown
$courses = $conn->query("SELECT * FROM course_master WHERE status='Active'");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Full Admission Entry | NLPTC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body { background-color: #f3f4f6; color: #333; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        
        /* Card Styling */
        .card { border: none; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.03); margin-bottom: 25px; transition: transform 0.2s; }
        .card-header { background-color: #fff; border-bottom: 1px solid #f0f0f0; padding: 20px; border-radius: 12px 12px 0 0 !important; }
        .card-header h5 { margin: 0; font-weight: 700; color: #2c3e50; display: flex; align-items: center; }
        
        /* Icons */
        .section-icon { 
            width: 32px; height: 32px; 
            background-color: #eef2ff; color: #4361ee; 
            border-radius: 8px; display: inline-flex; 
            align-items: center; justify-content: center; 
            margin-right: 12px; font-size: 14px;
        }

        /* Form Inputs */
        .form-label { font-weight: 600; font-size: 0.85rem; color: #64748b; margin-bottom: 6px; }
        .form-control, .form-select { 
            border-radius: 8px; border: 1px solid #e2e8f0; 
            padding: 10px 12px; font-size: 0.95rem; 
        }
        .form-control:focus, .form-select:focus { 
            border-color: #4361ee; box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.15); 
        }
        
        /* Table */
        .table thead th { background-color: #f8fafc; color: #475569; font-weight: 600; font-size: 0.85rem; border-bottom: 2px solid #e2e8f0; }
        
        /* Buttons */
        .btn-back { background-color: #fff; border: 1px solid #cbd5e1; color: #475569; font-weight: 600; }
        .btn-back:hover { background-color: #f1f5f9; }
        .btn-submit { 
            background: linear-gradient(135deg, #4361ee 0%, #3a0ca3 100%); 
            border: none; color: white; padding: 14px; 
            font-size: 1.1rem; font-weight: 600; border-radius: 8px; 
            box-shadow: 0 4px 6px rgba(67, 97, 238, 0.3);
        }
        .btn-submit:hover { opacity: 0.9; box-shadow: 0 6px 12px rgba(67, 97, 238, 0.4); }

        .required-asterisk { color: #ef4444; margin-left: 3px; }
    </style>
</head>
<body class="p-4">

<div class="container" style="max-width: 1100px;">
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold text-dark mb-0">Offline Admission Entry</h3>
            <p class="text-muted small mb-0">Manage new student admission applications</p>
        </div>
        <a href="dashboard.php" class="btn btn-back px-4 py-2">
            <i class="fas fa-arrow-left me-2"></i> Dashboard
        </a>
    </div>

    <form id="fullAdmissionForm" enctype="multipart/form-data">

        <div class="card">
            <div class="card-header">
                <h5><span class="section-icon"><i class="fas fa-university"></i></span> Course Selection</h5>
            </div>
            <div class="card-body">
                <div class="row g-4">
                    <div class="col-md-4">
                        <label class="form-label">Course Applied <span class="required-asterisk">*</span></label>
                        <select name="course_code" class="form-select" required>
                            <option value="">Select Course</option>
                            <?php while($c = $courses->fetch(PDO::FETCH_ASSOC)) { echo "<option value='{$c['course_code']}'>{$c['course_name']}</option>"; } ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Admission Type <span class="required-asterisk">*</span></label>
                        <select name="admission_type" id="admission_type" class="form-select" required onchange="toggleSubjects()">
                            <option value="">Select</option>
                            <option value="First Year">First Year (SSLC)</option>
                            <option value="Lateral Entry">Lateral Entry (HSC/ITI)</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Date of Joining <span class="required-asterisk">*</span></label>
                        <input type="date" name="doj" class="form-control" required value="<?= date('Y-m-d') ?>">
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h5><span class="section-icon"><i class="fas fa-user"></i></span> Personal Information</h5>
            </div>
            <div class="card-body">
                <div class="row g-3 mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Student Name (No Numbers) <span class="required-asterisk">*</span></label>
                        <input type="text" name="student_name" class="form-control" pattern="[a-zA-Z\s.]+" title="Only letters allowed" placeholder="Full Name" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Date of Birth <span class="required-asterisk">*</span></label>
                        <input type="date" name="dob" id="dob" class="form-control" onchange="calcAge()" required>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Age</label>
                        <input type="text" name="age" id="age" class="form-control bg-light" readonly>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Gender <span class="required-asterisk">*</span></label>
                        <select name="gender" class="form-select" required><option>Male</option><option>Female</option><option>Transgender</option></select>
                    </div>
                </div>

                <div class="row g-3 mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Father Name <span class="required-asterisk">*</span></label>
                        <input type="text" name="father_name" class="form-control" pattern="[a-zA-Z\s.]+" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Mother Name</label>
                        <input type="text" name="mother_name" class="form-control" pattern="[a-zA-Z\s.]+">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Guardian Name</label>
                        <input type="text" name="guardian_name" class="form-control" pattern="[a-zA-Z\s.]+">
                    </div>
                </div>

                <div class="row g-3 mb-3">
                    <div class="col-md-3">
                        <label class="form-label">Community <span class="required-asterisk">*</span></label>
                        <select name="community" class="form-select" required>
                            <option>OC</option><option>BC</option><option>BCM</option><option>MBC</option><option>DNC</option><option>SC</option><option>SCA</option><option>ST</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Caste</label>
                        <input type="text" name="caste" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Quota <span class="required-asterisk">*</span></label>
                        <select name="quota" class="form-select" required>
                            <option value="GQ">Govt Quota (GQ)</option>
                            <option value="MQ">Mgmt Quota (MQ)</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Religion</label>
                        <input type="text" name="religion" class="form-control" required>
                    </div>
                </div>

                <div class="row g-3 mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Mobile No (10 Digit) <span class="required-asterisk">*</span></label>
                        <input type="text" name="mobile_no" id="mobile_no" class="form-control" pattern="[0-9]{10}" maxlength="10" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Email ID</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Blood Group</label>
                        <select name="blood_group" class="form-select">
                            <option>O+</option><option>O-</option><option>A+</option><option>A-</option><option>B+</option><option>B-</option><option>AB+</option>
                        </select>
                    </div>
                </div>

                <div class="row g-3 mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Aadhar No (12 Digit) <span class="required-asterisk">*</span></label>
                        <input type="text" name="aadhar_no" id="aadhar_no" class="form-control" pattern="[0-9]{12}" maxlength="12" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">EMIS No (16 Digit)</label>
                        <input type="text" name="emis_no" class="form-control" pattern="[0-9]{16}" maxlength="16">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">UMIS No (16 Digit)</label>
                        <input type="text" name="umis_no" class="form-control" pattern="[0-9]{16}" maxlength="16">
                    </div>
                </div>

                <div class="col-12">
                    <label class="form-label">Communication Address</label>
                    <textarea name="address" class="form-control" rows="2" required></textarea>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h5><span class="section-icon"><i class="fas fa-graduation-cap"></i></span> Academic History & Marks</h5>
            </div>
            <div class="card-body">
                <div class="row g-3 mb-4">
                    <div class="col-md-6"><label class="form-label">School Name</label><input type="text" name="school_name" class="form-control" required></div>
                    <div class="col-md-6"><label class="form-label">School Place</label><input type="text" name="school_place" class="form-control" required></div>
                    <div class="col-md-3"><label class="form-label">Register No</label><input type="text" name="reg_no" class="form-control" required></div>
                    <div class="col-md-3"><label class="form-label">Year Passing</label><input type="number" name="year_passing" class="form-control" required></div>
                    <div class="col-md-3"><label class="form-label">Medium</label><input type="text" name="medium" class="form-control" required></div>
                    <div class="col-md-3"><label class="form-label">Board</label><input type="text" name="board" class="form-control" required></div>
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered mb-0">
                        <thead>
                            <tr>
                                <th style="width: 40%;">Subject</th>
                                <th style="width: 30%;">Max Marks (100)</th>
                                <th style="width: 30%;">Secured (0-100)</th>
                            </tr>
                        </thead>
                        <tbody id="marks_body"></tbody>
                        <tfoot class="bg-light">
                            <tr>
                                <th class="text-end">Total</th>
                                <th><input type="text" id="max_total" class="form-control form-control-sm bg-white" readonly></th>
                                <th><input type="text" id="sec_total" name="total_marks" class="form-control form-control-sm bg-white" readonly></th>
                            </tr>
                            <tr>
                                <th class="text-end">Percentage %</th>
                                <th colspan="2"><input type="text" id="percentage" name="percentage" class="form-control form-control-sm fw-bold text-success" readonly></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h5><span class="section-icon"><i class="fas fa-handshake"></i></span> Reference</h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Reference Type</label>
                        <select name="ref_type" id="ref_type" class="form-select" onchange="toggleRef()">
                            <option value="Direct">Direct Walk-in</option>
                            <option value="Student">Student</option>
                            <option value="Faculty">Faculty</option>
                            <option value="Alumni">Alumni</option>
                            <option value="Consultancy">Consultancy</option>
                        </select>
                    </div>
                    
                    <div class="col-md-4 ref-field d-none" id="div_ref_name"><label class="form-label">Referrer Name</label><input type="text" name="ref_name" class="form-control"></div>
                    <div class="col-md-4 ref-field d-none" id="div_ref_detail"><label class="form-label" id="lbl_ref_detail">Details</label><input type="text" name="ref_detail" class="form-control"></div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h5><span class="section-icon"><i class="fas fa-university"></i></span> Bank & Facilities</h5>
            </div>
            <div class="card-body">
                <div class="row g-3 mb-4">
                    <div class="col-md-3"><label class="form-label">Bank Name</label><input type="text" name="bank_name" class="form-control"></div>
                    <div class="col-md-3"><label class="form-label">Branch</label><input type="text" name="bank_branch" class="form-control"></div>
                    <div class="col-md-3"><label class="form-label">Account No (11-16)</label><input type="text" name="acc_no" class="form-control" pattern="[0-9]{11,16}"></div>
                    <div class="col-md-3"><label class="form-label">IFSC Code</label><input type="text" name="ifsc" class="form-control"></div>
                </div>
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Transport Required?</label>
                        <select name="transport" id="transport" class="form-select" onchange="if(this.value=='Yes'){$('#trans_place').show();}else{$('#trans_place').hide();}"><option>No</option><option>Yes</option></select>
                    </div>
                    <div class="col-md-4" id="trans_place" style="display:none;">
                        <label class="form-label">Boarding Place</label><input type="text" name="boarding_place" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Hostel Required?</label>
                        <select name="hostel" class="form-select"><option>No</option><option>Yes</option></select>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h5><span class="section-icon"><i class="fas fa-file-invoice-dollar"></i></span> Fee Payment & Documents</h5>
            </div>
            <div class="card-body">
                <div class="row g-4 mb-4">
                    <div class="col-md-4">
                        <label class="form-label"><i class="fas fa-image me-1"></i> Student Photo</label>
                        <input type="file" name="photo" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label"><i class="fas fa-id-card me-1"></i> Aadhar Card</label>
                        <input type="file" name="doc_aadhar" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label"><i class="fas fa-certificate me-1"></i> Community Cert</label>
                        <input type="file" name="doc_comm" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label"><i class="fas fa-file-alt me-1"></i> TC</label>
                        <input type="file" name="doc_tc" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label"><i class="fas fa-file-alt me-1"></i> Mark Sheet</label>
                        <input type="file" name="doc_mark" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label"><i class="fas fa-receipt me-1"></i> Fee Receipt</label>
                        <input type="file" name="doc_receipt" class="form-control" required>
                    </div>
                </div>
                
                <div class="row g-3 p-3 bg-light rounded border">
                    <div class="col-md-6">
                        <label class="form-label fw-bold text-dark">Fees Amount Paid</label>
                        <div class="input-group">
                            <span class="input-group-text">₹</span>
                            <input type="number" name="fee_amount" class="form-control" required placeholder="0.00">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold text-dark">Payment Date</label>
                        <input type="date" name="pay_date" class="form-control" required value="<?= date('Y-m-d') ?>">
                    </div>
                </div>
            </div>
        </div>

        <div class="d-grid mb-5">
            <button type="submit" id="submitBtn" class="btn-submit">
                <i class="fas fa-check-circle me-2"></i> FINAL SUBMIT & ADMIT STUDENT
            </button>
        </div>
    </form>
</div>

<script>
    // 1. Age Calculation
    function calcAge() {
        let dobVal = document.getElementById('dob').value;
        if(dobVal) {
            let dob = new Date(dobVal);
            let diff = Date.now() - dob.getTime();
            let age = new Date(diff).getUTCFullYear() - 1970;
            document.getElementById('age').value = Math.abs(age);
        }
    }

    // 2. Dynamic Marks Table
    function toggleSubjects() {
        let type = document.getElementById('admission_type').value;
        let tbody = document.getElementById('marks_body');
        tbody.innerHTML = '';
        
        let subjects = (type === 'First Year') 
            ? ['Tamil','English','Mathematics','Science','Social Science'] 
            : ['Subject 1','Subject 2','Subject 3','Subject 4','Subject 5','Subject 6'];

        subjects.forEach(sub => {
            let row = `<tr>
                <td><input type="text" name="sub_name[]" value="${sub}" class="form-control form-control-sm" readonly></td>
                <td><input type="number" name="max_mark[]" value="100" class="form-control form-control-sm" readonly></td>
                <td><input type="number" name="sec_mark[]" class="form-control form-control-sm mark-input" min="0" max="100" oninput="calcTotal()" required></td>
            </tr>`;
            tbody.innerHTML += row;
        });
        calcTotal();
    }

    // 3. Calculate Total & Percentage
    function calcTotal() {
        let total = 0; 
        let maxTotal = 0;
        document.querySelectorAll('.mark-input').forEach(i => {
            let val = parseFloat(i.value) || 0;
            if(val > 100) { alert('Marks cannot be > 100'); i.value=0; val=0; }
            total += val;
            maxTotal += 100;
        });
        document.getElementById('sec_total').value = total;
        document.getElementById('max_total').value = maxTotal;
        document.getElementById('percentage').value = (maxTotal > 0) ? ((total/maxTotal)*100).toFixed(2) + '%' : '0%';
    }

    // 4. Reference Toggle Logic
    function toggleRef() {
        let type = document.getElementById('ref_type').value;
        $('.ref-field').addClass('d-none');
        
        if(type !== 'Direct') {
            $('#div_ref_name').removeClass('d-none');
            $('#div_ref_detail').removeClass('d-none');
            
            let label = "Details";
            if(type === 'Student') label = "Year & Dept";
            if(type === 'Alumni') label = "Batch Year";
            if(type === 'Faculty') label = "Department";
            if(type === 'Consultancy') label = "Contact No";
            
            $('#lbl_ref_detail').text(label);
        }
    }

    // 5. Submit AJAX Logic
    $('#fullAdmissionForm').on('submit', async function(e){
        e.preventDefault();
        
        // Final Validation
        if(document.getElementById('mobile_no').value.length !== 10) return alert("Mobile must be 10 digits");
        if(document.getElementById('aadhar_no').value.length !== 12) return alert("Aadhar must be 12 digits");

        if(!confirm("Confirm Admission? Verify all details before submitting.")) return;

        let btn = document.getElementById('submitBtn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i> Processing...';

        let formData = new FormData(this);

        try {
            let res = await fetch('../api/admin/process_offline_admission.php', { 
                method: 'POST', 
                body: formData 
            });
            
            let text = await res.text();
            console.log("Server Response:", text); 

            try {
                let result = JSON.parse(text); 
                if(result.status === 'success') {
                    alert("✅ Admission Successful!\n\nStudent ID: " + result.student_id);
                    window.location.href = 'dashboard.php';
                } else {
                    alert("❌ Error: " + result.message);
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-check-circle me-2"></i> FINAL SUBMIT & ADMIT STUDENT';
                }
            } catch(e) {
                alert("Server Error! Check Console for details.");
                console.error("JSON Parse Error:", e);
                btn.disabled = false;
                btn.innerText = "Try Again";
            }

        } catch(err) { 
            alert("Network Error! Check console."); 
            console.error(err);
            btn.disabled = false;
        }
    });
</script>

</body>
</html>