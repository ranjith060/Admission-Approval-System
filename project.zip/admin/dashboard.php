<?php
require_once '../includes/auth_session.php';
require_once '../config/db.php';
checkLogin('ADMIN');

// Basic Stats
$total_students = $conn->query("SELECT COUNT(*) FROM student_master")->fetchColumn();
$pending_apps = $conn->query("SELECT COUNT(*) FROM admission_applications WHERE app_status='Submitted'")->fetchColumn();
$total_faculty = $conn->query("SELECT COUNT(*) FROM faculty_master")->fetchColumn();
$total_courses = $conn->query("SELECT COUNT(*) FROM course_master")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | NLPTC ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

    <?php include 'includes/sidebar.php'; ?>

    <div class="content">
        <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm rounded mb-4 p-3">
            <div class="container-fluid">
                <span class="navbar-brand fw-bold text-secondary"><i class="fas fa-bars me-2"></i> Dashboard Overview</span>
                <div class="d-flex align-items-center">
                    <span class="me-3 fw-bold text-muted d-none d-md-block">Hello, Admin</span>
                    <a href="profile.php" class="btn btn-outline-primary btn-sm rounded-pill px-3">
                        <i class="fas fa-user-circle me-1"></i> Profile
                    </a>
                </div>
            </div>
        </nav>

        <div class="row g-4">
            <div class="col-md-3">
                <div class="stat-card bg-blue text-white p-3 rounded">
                    <p class="mb-1">Total Admitted Students</p>
                    <h3 class="fw-bold"><?= $total_students ?></h3>
                    <i class="fas fa-user-graduate float-end fs-1 opacity-25"></i>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="stat-card bg-orange text-white p-3 rounded">
                    <p class="mb-1">Pending Applications</p>
                    <h3 class="fw-bold"><?= $pending_apps ?></h3>
                    <i class="fas fa-file-invoice float-end fs-1 opacity-25"></i>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stat-card bg-green text-white p-3 rounded">
                    <p class="mb-1">Total Faculty</p>
                    <h3 class="fw-bold"><?= $total_faculty ?></h3>
                    <i class="fas fa-chalkboard-teacher float-end fs-1 opacity-25"></i>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stat-card bg-red text-white p-3 rounded">
                    <p class="mb-1">Active Courses</p>
                    <h3 class="fw-bold"><?= $total_courses ?></h3>
                    <i class="fas fa-university float-end fs-1 opacity-25"></i>
                </div>
            </div>
        </div>

        <div class="row mt-5">
            <div class="col-md-12">
                <div class="card shadow-sm">
                    <div class="card-header bg-white fw-bold">
                        <i class="fas fa-bolt text-warning me-2"></i> Quick Actions
                    </div>
                    <div class="card-body">
                        <div class="row text-center">
                            <div class="col-md-2">
                                <a href="offline_admission.php" class="btn btn-outline-primary w-100 py-3">
                                    <i class="fas fa-user-plus fa-2x mb-2"></i><br>New Admission
                                </a>
                            </div>
                            <div class="col-md-2">
                                <a href="applications.php" class="btn btn-outline-success w-100 py-3">
                                    <i class="fas fa-check-double fa-2x mb-2"></i><br>Verify Apps
                                </a>
                            </div>
                            <div class="col-md-2">
                                <a href="manage_subjects.php" class="btn btn-outline-info w-100 py-3">
                                    <i class="fas fa-book fa-2x mb-2"></i><br>Add Subject
                                </a>
                            </div>
                            <div class="col-md-2">
                                <a href="dote_reports.php" class="btn btn-outline-secondary w-100 py-3">
                                    <i class="fas fa-print fa-2x mb-2"></i><br>DOTE Reports
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .bg-blue { background: linear-gradient(45deg, #4099ff, #73b4ff); }
        .bg-green { background: linear-gradient(45deg, #2ed8b6, #59e0c5); }
        .bg-orange { background: linear-gradient(45deg, #FFB64D, #ffcb80); }
        .bg-red { background: linear-gradient(45deg, #FF5370, #ff869a); }
    </style>
</body>
</html>