<div class="sidebar">
    <h4 class="text-center py-3 border-bottom border-secondary">NLPTC ADMIN</h4>
    
    <a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?>">
        <i class="fas fa-tachometer-alt"></i> Dashboard
    </a>
    
    <a href="offline_admission.php" class="<?= basename($_SERVER['PHP_SELF']) == 'offline_admission.php' ? 'active' : '' ?>">
        <i class="fas fa-user-plus"></i> Admission
    </a>

    <a href="applications.php" class="<?= basename($_SERVER['PHP_SELF']) == 'applications.php' ? 'active' : '' ?>">
        <i class="fas fa-users"></i> Applications
    </a>
    
    <a href="manage_courses.php" class="<?= basename($_SERVER['PHP_SELF']) == 'manage_courses.php' ? 'active' : '' ?>">
        <i class="fas fa-graduation-cap"></i> Manage Courses
    </a>

    <a href="manage_subjects.php" class="<?= basename($_SERVER['PHP_SELF']) == 'manage_subjects.php' ? 'active' : '' ?>">
        <i class="fas fa-book"></i> Manage Subjects
    </a>
    
    <a href="manage_faculty.php" class="<?= basename($_SERVER['PHP_SELF']) == 'manage_faculty.php' ? 'active' : '' ?>">
        <i class="fas fa-chalkboard-teacher"></i> Manage Faculty
    </a>

    <a href="manage_academic_years.php" class="<?= basename($_SERVER['PHP_SELF']) == 'manage_academic_years.php' ? 'active' : '' ?>">
        <i class="fas fa-calendar-alt"></i> Academic Years
    </a>

    <a href="dote_reports.php" class="<?= basename($_SERVER['PHP_SELF']) == 'dote_reports.php' ? 'active' : '' ?>">
        <i class="fas fa-file-alt"></i> DOTE Reports
    </a>

    <a href="settings.php" class="<?= basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : '' ?>">
        <i class="fas fa-cogs"></i> Settings
    </a>

    <div style="margin-top: 50px;">
        <a href="../logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</div>

<style>
    /* Global Sidebar Style for Consistency */
    body { background-color: #f4f6f9; }
    .sidebar { height: 100vh; width: 250px; position: fixed; top: 0; left: 0; background-color: #2c3e50; color: white; z-index: 1000; overflow-y: auto; transition: 0.3s; }
    .sidebar h4 { color: #ecf0f1; font-weight: bold; letter-spacing: 1px; }
    .sidebar a { padding: 15px 25px; text-decoration: none; font-size: 16px; color: #bdc3c7; display: block; transition: 0.3s; border-left: 4px solid transparent; }
    .sidebar a:hover, .sidebar a.active { background-color: #34495e; color: white; border-left: 4px solid #3498db; padding-left: 21px; }
    .sidebar i { width: 25px; text-align: center; margin-right: 10px; }
    .content { margin-left: 250px; padding: 30px; transition: 0.3s; }
    
    /* Mobile Responsive */
    @media (max-width: 768px) {
        .sidebar { width: 70px; }
        .sidebar a span, .sidebar h4 { display: none; } /* Hide text on mobile */
        .sidebar a { padding: 15px 10px; text-align: center; }
        .sidebar i { margin: 0; }
        .content { margin-left: 70px; }
    }
</style>