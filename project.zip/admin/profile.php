<?php
require_once '../includes/auth_session.php';
require_once '../config/db.php';
checkLogin('ADMIN');

$user_id = $_SESSION['user_uid'];
$msg = "";

// Handle Profile Update
if (isset($_POST['update_profile'])) {
    $name = $_POST['username'];
    $phone = $_POST['mobile_no'];
    
    $update = $conn->prepare("UPDATE users SET username=?, mobile_no=? WHERE user_uid=?");
    $update->execute([$name, $phone, $user_id]);
    $_SESSION['username'] = $name; // Update Session
    $msg = "<div class='alert alert-success'>Profile Updated!</div>";
}

// Handle Password Change
if (isset($_POST['change_password'])) {
    $new_pass = $_POST['new_password'];
    $confirm_pass = $_POST['confirm_password'];

    if ($new_pass === $confirm_pass) {
        $hash = password_hash($new_pass, PASSWORD_DEFAULT);
        $update = $conn->prepare("UPDATE users SET password_hash=? WHERE user_uid=?");
        $update->execute([$hash, $user_id]);
        $msg = "<div class='alert alert-success'>Password Changed Successfully!</div>";
    } else {
        $msg = "<div class='alert alert-danger'>Passwords do not match!</div>";
    }
}

// Fetch Admin Data
$stmt = $conn->prepare("SELECT * FROM users WHERE user_uid = ?");
$stmt->execute([$user_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>My Profile | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

    <?php include 'includes/sidebar.php'; ?>

    <div class="content">
        <h2 class="mb-4">My Profile</h2>
        <?= $msg ?>

        <div class="row">
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">Personal Details</div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label>Full Name</label>
                                <input type="text" name="username" class="form-control" value="<?= $admin['username'] ?>" required>
                            </div>
                            <div class="mb-3">
                                <label>Email (Cannot Change)</label>
                                <input type="email" class="form-control" value="<?= $admin['email'] ?>" readonly>
                            </div>
                            <div class="mb-3">
                                <label>Mobile Number</label>
                                <input type="text" name="mobile_no" class="form-control" value="<?= $admin['mobile_no'] ?>" required pattern="\d{10}">
                            </div>
                            <button type="submit" name="update_profile" class="btn btn-primary">Update Profile</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-header bg-danger text-white">Change Password</div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label>New Password</label>
                                <input type="password" name="new_password" class="form-control" required minlength="6">
                            </div>
                            <div class="mb-3">
                                <label>Confirm Password</label>
                                <input type="password" name="confirm_password" class="form-control" required minlength="6">
                            </div>
                            <button type="submit" name="change_password" class="btn btn-danger">Change Password</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>