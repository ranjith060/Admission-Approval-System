<?php
require_once '../includes/auth_session.php';
require_once '../config/db.php';
checkLogin('ADMIN');

if (!isset($_GET['id'])) {
    header("Location: applications.php");
    exit();
}

$app_no = $_GET['id'];

// 1. Fetch Application Details
$stmt = $conn->prepare("SELECT a.*, c.course_name, c.course_short 
                        FROM admission_applications a 
                        LEFT JOIN course_master c ON a.course_code_pref = c.course_code 
                        WHERE a.application_no = ?");
$stmt->execute([$app_no]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) die("Application not found.");

// 2. Fetch Marks
$stmt_marks = $conn->prepare("SELECT * FROM admission_marks WHERE application_no = ?");
$stmt_marks->execute([$app_no]);
$marks = $stmt_marks->fetchAll(PDO::FETCH_ASSOC);

// 3. Fetch Documents
$stmt_docs = $conn->prepare("SELECT * FROM admission_documents WHERE application_no = ?");
$stmt_docs->execute([$app_no]);
$docs = $stmt_docs->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Verify Student | NLPTC ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .doc-preview { width: 100%; height: 150px; object-fit: cover; border: 1px solid #ddd; border-radius: 5px; cursor: pointer; transition: 0.3s; }
        .doc-preview:hover { opacity: 0.8; border-color: #0d6efd; }
    </style>
</head>
<body class="bg-light p-4">

<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3><i class="fas fa-user-check"></i> Verify Application: <span class="text-primary"><?= $app_no ?></span></h3>
        <a href="applications.php" class="btn btn-secondary">Back to List</a>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-dark text-white">Basic Information</div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-6"><label class="text-muted">Student Name</label><h5><?= $student['student_name'] ?></h5></div>
                        <div class="col-md-6"><label class="text-muted">Course Applied</label><h5><?= $student['course_name'] ?> (<?= $student['course_short'] ?>)</h5></div>
                        <div class="col-md-4"><label class="text-muted">Community</label><p class="fw-bold"><?= $student['community_class'] ?></p></div>
                        <div class="col-md-4"><label class="text-muted">DOB</label><p class="fw-bold"><?= $student['dob'] ?></p></div>
                        <div class="col-md-4"><label class="text-muted">Gender</label><p class="fw-bold"><?= $student['gender'] ?></p></div>
                        <div class="col-md-6"><label class="text-muted">Father Name</label><p class="fw-bold"><?= $student['father_name'] ?></p></div>
                        <div class="col-md-6"><label class="text-muted">Mobile</label><p class="fw-bold"><?= $student['mobile_no'] ?></p></div>
                    </div>
                </div>
            </div>

            <div class="card shadow-sm mb-4">
                <div class="card-header bg-info text-white">Academic Marks</div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead><tr><th>Subject</th><th>Marks Obtained</th><th>Max Marks</th></tr></thead>
                        <tbody>
                            <?php foreach($marks as $m): ?>
                            <tr>
                                <td><?= $m['subject_name'] ?></td>
                                <td><?= $m['marks_obtained'] ?></td>
                                <td><?= $m['max_marks'] ?></td>
                            </tr>
                            <?php endforeach; ?>
                            <tr class="table-light">
                                <td colspan="3" class="text-end fw-bold">Calculated Percentage: <?= $student['calculated_percentage'] ?>%</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            
            <div class="card shadow-sm mb-4">
                <div class="card-body text-center">
                    <h5>Current Status</h5>
                    <span class="badge bg-<?= $student['app_status']=='Admitted'?'success':($student['app_status']=='Rejected'?'danger':'warning') ?> fs-5 mb-3">
                        <?= $student['app_status'] ?>
                    </span>
                    
                    <?php if($student['app_status'] != 'Admitted'): ?>
                        <div class="d-grid gap-2">
                            <button onclick="updateStatus('Verified')" class="btn btn-outline-primary">Mark as Verified</button>
                            <button onclick="updateStatus('Admitted')" class="btn btn-success">Confirm Admission</button>
                            <button onclick="updateStatus('Rejected')" class="btn btn-danger">Reject Application</button>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-success mt-2">Admission Confirmed!</div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card shadow-sm">
                <div class="card-header bg-secondary text-white">Uploaded Documents</div>
                <div class="card-body">
                    <div class="row g-2">
                        <?php foreach($docs as $d): ?>
                        <div class="col-6 text-center">
                            <a href="../<?= $d['file_path'] ?>" target="_blank">
                                <img src="../<?= $d['file_path'] ?>" class="doc-preview">
                            </a>
                            <small class="d-block mt-1"><?= $d['doc_type'] ?></small>
                        </div>
                        <?php endforeach; ?>
                        <?php if(empty($docs)) echo "<p class='text-muted text-center'>No documents uploaded.</p>"; ?>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<script>
async function updateStatus(status) {
    if(!confirm(`Are you sure you want to mark this application as ${status}?`)) return;

    const formData = new FormData();
    formData.append('app_no', '<?= $app_no ?>');
    formData.append('status', status);

    try {
        const res = await fetch('../api/admin/update_status.php', { method: 'POST', body: formData });
        const result = await res.json();
        
        if(result.status === 'success') {
            alert(result.message);
            location.reload();
        } else {
            alert("Error: " + result.message);
        }
    } catch(err) {
        alert("Network Error");
    }
}
</script>

</body>
</html>