<?php
require_once '../includes/auth_session.php';
require_once '../config/db.php';
checkLogin('ADMIN');

$edit_mode = false;
$edit_data = [];
$msg = "";
$msg_type = "";

// --- HANDLE POST ACTIONS ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // 1. ADD YEAR
    if (isset($_POST['add_year'])) {
        try {
            $stmt = $conn->prepare("INSERT INTO academic_years (ay_code, ay_short_code, start_date, end_date, status) VALUES (?, ?, ?, ?, 'Inactive')");
            if($stmt->execute([$_POST['code'], $_POST['short'], $_POST['start'], $_POST['end']])) {
                $msg = "Academic Year Added Successfully!";
                $msg_type = "success";
            }
        } catch (PDOException $e) {
            $msg = "Error: " . $e->getMessage();
            $msg_type = "danger";
        }
    }

    // 2. UPDATE YEAR
    if (isset($_POST['update_year'])) {
        try {
            $stmt = $conn->prepare("UPDATE academic_years SET ay_short_code=?, start_date=?, end_date=? WHERE ay_code=?");
            if($stmt->execute([$_POST['short'], $_POST['start'], $_POST['end'], $_POST['code']])) {
                $msg = "Academic Year Updated Successfully!";
                $msg_type = "success";
            }
        } catch (PDOException $e) {
            $msg = "Error Updating: " . $e->getMessage();
            $msg_type = "danger";
        }
    }

    // 3. TOGGLE STATUS
    if (isset($_POST['toggle_status'])) {
        $ay_code = $_POST['ay_code'];
        $new_status = ($_POST['current_status'] == 'Active') ? 'Inactive' : 'Active';

        $conn->beginTransaction();
        if ($new_status == 'Active') {
            // Deactivate all others first
            $conn->query("UPDATE academic_years SET status='Inactive'");
        }
        $stmt = $conn->prepare("UPDATE academic_years SET status=? WHERE ay_code=?");
        $stmt->execute([$new_status, $ay_code]);
        $conn->commit();
        
        header("Location: manage_academic_years.php");
        exit();
    }

    // 4. SOFT DELETE
    if (isset($_POST['delete_year'])) {
        $stmt = $conn->prepare("UPDATE academic_years SET is_deleted=1 WHERE ay_code=?");
        $stmt->execute([$_POST['ay_code']]);
        $msg = "Academic Year Moved to Recycle Bin!";
        $msg_type = "warning";
    }
}

// --- HANDLE EDIT GET REQUEST ---
if (isset($_GET['edit'])) {
    $edit_mode = true;
    $stmt = $conn->prepare("SELECT * FROM academic_years WHERE ay_code = ?");
    $stmt->execute([$_GET['edit']]);
    $edit_data = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Academic Years | NLPTC ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

    <?php include 'includes/sidebar.php'; ?>

    <div class="content">
        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold text-primary"><i class="fas fa-calendar-alt"></i> Academic Years</h2>
            <a href="dashboard.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i> Back to Dashboard
            </a>
        </div>

        <?php if (!empty($msg)): ?>
            <div class="alert alert-<?= $msg_type ?> alert-dismissible fade show" role="alert">
                <?= $msg ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-4">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-dark text-white fw-bold">
                        <?= $edit_mode ? '<i class="fas fa-edit"></i> Edit Year' : '<i class="fas fa-plus-circle"></i> Add New Year' ?>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="manage_academic_years.php">
                            
                            <div class="mb-3">
                                <label class="form-label fw-bold">Academic Year Code</label>
                                <input type="text" name="code" class="form-control" placeholder="2025-2026" 
                                    value="<?= $edit_mode ? $edit_data['ay_code'] : '' ?>" 
                                    <?= $edit_mode ? 'readonly' : 'required' ?>>
                                <?php if($edit_mode): ?>
                                    <small class="text-muted">Unique Code cannot be changed.</small>
                                <?php endif; ?>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-bold">Short Code</label>
                                <input type="text" name="short" class="form-control" placeholder="2526" 
                                    value="<?= $edit_mode ? $edit_data['ay_short_code'] : '' ?>" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-bold">Start Date</label>
                                <input type="date" name="start" class="form-control" 
                                    value="<?= $edit_mode ? $edit_data['start_date'] : '' ?>" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-bold">End Date</label>
                                <input type="date" name="end" class="form-control" 
                                    value="<?= $edit_mode ? $edit_data['end_date'] : '' ?>" required>
                            </div>

                            <div class="d-grid gap-2">
                                <?php if($edit_mode): ?>
                                    <button type="submit" name="update_year" class="btn btn-warning fw-bold">
                                        <i class="fas fa-save"></i> Update Year
                                    </button>
                                    <a href="manage_academic_years.php" class="btn btn-outline-secondary">Cancel</a>
                                <?php else: ?>
                                    <button type="submit" name="add_year" class="btn btn-primary fw-bold">
                                        <i class="fas fa-plus"></i> Add Year
                                    </button>
                                <?php endif; ?>
                            </div>

                        </form>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white fw-bold">
                        <i class="fas fa-list-ul me-2"></i> Year List
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Year Code</th>
                                        <th>Short Code</th>
                                        <th>Duration</th>
                                        <th class="text-center">Status</th>
                                        <th class="text-center">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $years = $conn->query("SELECT * FROM academic_years WHERE is_deleted=0 ORDER BY ay_code DESC");
                                    while($row = $years->fetch()):
                                        $statusBadge = $row['status'] == 'Active' ? 'success' : 'secondary';
                                    ?>
                                    <tr>
                                        <td class="fw-bold text-primary"><?= $row['ay_code'] ?></td>
                                        <td><span class="badge bg-info text-dark"><?= $row['ay_short_code'] ?></span></td>
                                        <td>
                                            <small class="text-muted">
                                                <?= date('M Y', strtotime($row['start_date'])) ?> - <?= date('M Y', strtotime($row['end_date'])) ?>
                                            </small>
                                        </td>
                                        
                                        <td class="text-center">
                                            <span class="badge bg-<?= $statusBadge ?>"><?= $row['status'] ?></span>
                                        </td>

                                        <td class="text-center">
                                            <div class="btn-group" role="group">
                                                
                                                <a href="manage_academic_years.php?edit=<?= $row['ay_code'] ?>" class="btn btn-sm btn-outline-warning" title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>

                                                <form method="POST" style="display:inline;">
                                                    <input type="hidden" name="ay_code" value="<?= $row['ay_code'] ?>">
                                                    <input type="hidden" name="current_status" value="<?= $row['status'] ?>">
                                                    <button type="submit" name="toggle_status" class="btn btn-sm btn-outline-primary" title="Toggle Status">
                                                        <i class="fas fa-power-off"></i>
                                                    </button>
                                                </form>

                                                <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this year?');">
                                                    <input type="hidden" name="ay_code" value="<?= $row['ay_code'] ?>">
                                                    <button type="submit" name="delete_year" class="btn btn-sm btn-outline-danger" title="Delete">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                </form>

                                            </div>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>