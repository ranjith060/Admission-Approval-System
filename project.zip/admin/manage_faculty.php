<?php
require_once '../includes/auth_session.php';
require_once '../config/db.php';
checkLogin('ADMIN');

// Fetch Departments for Filter
$departments = $conn->query("SELECT * FROM course_master WHERE status='Active'");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Manage Faculty | NLPTC ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>
    <style>
        .faculty-img { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; border: 2px solid #fff; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .action-btn { width: 32px; height: 32px; line-height: 32px; text-align: center; padding: 0; border-radius: 50%; display: inline-block; margin-right: 5px; }
        .status-dot { height: 10px; width: 10px; background-color: #bbb; border-radius: 50%; display: inline-block; }
        .status-active { background-color: #28a745; }
        .status-inactive { background-color: #dc3545; }
    </style>
</head>
<body>

    <?php include 'includes/sidebar.php'; ?>

    <div class="content">
        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold text-primary"><i class="fas fa-chalkboard-teacher"></i> Manage Faculty</h2>
            <div>
                <button class="btn btn-success me-2" onclick="exportTable()">
                    <i class="fas fa-file-excel me-2"></i> Export
                </button>
                <button class="btn btn-primary" onclick="openAddModal()">
                    <i class="fas fa-user-plus me-2"></i> Add Faculty
                </button>
            </div>
        </div>

        <div class="card shadow-sm mb-4">
            <div class="card-body bg-light">
                <div class="row g-3">
                    <div class="col-md-5">
                        <div class="input-group">
                            <span class="input-group-text bg-white"><i class="fas fa-search text-muted"></i></span>
                            <input type="text" id="searchInput" class="form-control" placeholder="Search by Name, ID or Email...">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <select id="deptFilter" class="form-select">
                            <option value="">All Departments</option>
                            <?php while($d = $departments->fetch(PDO::FETCH_ASSOC)): ?>
                                <option value="<?= $d['course_short'] ?>"><?= $d['course_name'] ?> (<?= $d['course_short'] ?>)</option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <button class="btn btn-secondary w-100" onclick="resetFilters()">Reset Filters</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="card shadow-sm border-0">
            <div class="card-body p-0">
                <div class="table-responsive" style="max-height: 600px; overflow-y: auto;">
                    <table class="table table-hover align-middle mb-0" id="facultyTable">
                        <thead class="table-dark sticky-top">
                            <tr>
                                <th>ID</th>
                                <th>Profile</th>
                                <th>Name / Email</th>
                                <th>Designation</th>
                                <th>Dept</th>
                                <th>Mobile</th>
                                <th class="text-center">Status</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql = "SELECT f.*, c.course_short, c.course_name 
                                    FROM faculty_master f 
                                    LEFT JOIN course_master c ON f.course_code = c.course_code
                                    WHERE f.is_deleted = 0 
                                    ORDER BY f.created_at DESC";
                            $stmt = $conn->query($sql);
                            
                            while($row = $stmt->fetch(PDO::FETCH_ASSOC)):
                                $img = !empty($row['profile_photo']) ? '../'.$row['profile_photo'] : 'https://via.placeholder.com/50';
                                $statusClass = ($row['status'] == 'active') ? 'status-active' : 'status-inactive';
                                $statusTitle = ucfirst($row['status']);
                            ?>
                            <tr data-dept="<?= $row['course_short'] ?>">
                                <td class="fw-bold text-secondary"><?= $row['faculty_id'] ?></td>
                                <td><img src="<?= $img ?>" class="faculty-img"></td>
                                <td>
                                    <div class="fw-bold text-dark"><?= $row['first_name'] . ' ' . $row['last_name'] ?></div>
                                    <small class="text-muted"><?= $row['email'] ?></small>
                                </td>
                                <td><?= $row['designation'] ?></td>
                                <td><span class="badge bg-info text-dark"><?= $row['course_short'] ?></span></td>
                                <td><?= $row['phone'] ?></td>
                                <td class="text-center">
                                    <span class="status-dot <?= $statusClass ?>" title="<?= $statusTitle ?>"></span>
                                    <small class="ms-1 d-none d-md-inline"><?= $statusTitle ?></small>
                                </td>
                                <td class="text-center">
                                    <div class="btn-group" role="group">
                                        <button class="btn btn-sm btn-outline-info" onclick="viewFaculty('<?= $row['faculty_id'] ?>')" title="View">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-warning" onclick="editFaculty('<?= $row['faculty_id'] ?>')" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-secondary" onclick="toggleStatus('<?= $row['faculty_id'] ?>', '<?= $row['status'] ?>')" title="Toggle Status">
                                            <i class="fas fa-power-off"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger" onclick="deleteFaculty('<?= $row['faculty_id'] ?>')" title="Delete">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    <div id="noRecords" class="text-center p-5 text-muted d-none">
                        <i class="fas fa-search fa-3x mb-3 text-secondary"></i>
                        <h5>No Faculty Found</h5>
                        <p>Try adjusting your search or filters.</p>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="modal fade" id="facultyModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalTitle">Add New Faculty</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="facultyForm" enctype="multipart/form-data">
                        <input type="hidden" name="action" id="formAction" value="add">
                        <input type="hidden" name="faculty_id" id="f_id">
                        
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">First Name <span class="text-danger">*</span></label>
                                <input type="text" name="first_name" id="f_fname" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Last Name</label>
                                <input type="text" name="last_name" id="f_lname" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Email <span class="text-danger">*</span></label>
                                <input type="email" name="email" id="f_email" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Phone <span class="text-danger">*</span></label>
                                <input type="text" name="phone" id="f_phone" class="form-control" pattern="\d{10}" title="10 digit mobile number" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Department</label>
                                <select name="course_code" id="f_dept" class="form-select" required>
                                    <option value="">Select Dept</option>
                                    <?php 
                                    $departments->execute(); // Reset pointer
                                    while($d=$departments->fetch(PDO::FETCH_ASSOC)) echo "<option value='{$d['course_code']}'>{$d['course_short']}</option>";
                                    ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Designation</label>
                                <select name="designation" id="f_desig" class="form-select">
                                    <option>Lecturer</option><option>Senior Lecturer</option>
                                    <option>HOD</option><option>Lab Assistant</option>
                                    <option>Principal</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Qualification</label>
                                <input type="text" name="qualification" id="f_qual" class="form-control" placeholder="e.g. M.E (CSE)">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Specialization</label>
                                <input type="text" name="specialization" id="f_spec" class="form-control" placeholder="e.g. AI & ML">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Date of Joining</label>
                                <input type="date" name="date_of_joining" id="f_doj" class="form-control">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Profile Photo</label>
                                <input type="file" name="profile_photo" class="form-control" accept="image/*">
                                <small class="text-muted">Leave blank to keep existing photo (Edit mode)</small>
                            </div>
                        </div>
                        <div class="mt-4 text-end">
                            <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success px-4">Save Faculty</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="viewModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h5 class="modal-title">Faculty Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-center">
                    <img id="v_photo" src="" class="rounded-circle mb-3 border shadow-sm" style="width: 100px; height: 100px; object-fit: cover;">
                    <h4 id="v_name" class="fw-bold"></h4>
                    <p id="v_desig_dept" class="text-muted mb-3"></p>
                    
                    <ul class="list-group list-group-flush text-start">
                        <li class="list-group-item"><strong>ID:</strong> <span id="v_id"></span></li>
                        <li class="list-group-item"><strong>Email:</strong> <span id="v_email"></span></li>
                        <li class="list-group-item"><strong>Phone:</strong> <span id="v_phone"></span></li>
                        <li class="list-group-item"><strong>Qualification:</strong> <span id="v_qual"></span></li>
                        <li class="list-group-item"><strong>Specialization:</strong> <span id="v_spec"></span></li>
                        <li class="list-group-item"><strong>Joined On:</strong> <span id="v_doj"></span></li>
                        <li class="list-group-item"><strong>Status:</strong> <span id="v_status" class="badge"></span></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const modal = new bootstrap.Modal(document.getElementById('facultyModal'));
        const viewModal = new bootstrap.Modal(document.getElementById('viewModal'));

        // --- FILTER LOGIC ---
        const searchInput = document.getElementById('searchInput');
        const deptFilter = document.getElementById('deptFilter');
        const tableRows = document.querySelectorAll('#facultyTable tbody tr');
        const noRecords = document.getElementById('noRecords');

        function filterTable() {
            const term = searchInput.value.toLowerCase();
            const dept = deptFilter.value;
            let visibleCount = 0;

            tableRows.forEach(row => {
                const text = row.innerText.toLowerCase();
                const rowDept = row.dataset.dept;
                const matchesSearch = text.includes(term);
                const matchesDept = dept === "" || rowDept === dept;

                if (matchesSearch && matchesDept) {
                    row.style.display = "";
                    visibleCount++;
                } else {
                    row.style.display = "none";
                }
            });
            noRecords.classList.toggle('d-none', visibleCount > 0);
        }

        searchInput.addEventListener('keyup', filterTable);
        deptFilter.addEventListener('change', filterTable);

        function resetFilters() {
            searchInput.value = "";
            deptFilter.value = "";
            filterTable();
        }

        function exportTable() {
            const table = document.getElementById("facultyTable");
            // Clone table to remove action column for export if needed, or just export raw
            const wb = XLSX.utils.table_to_book(table, {sheet: "Faculty List"});
            XLSX.writeFile(wb, "Faculty_List.xlsx");
        }

        // --- CRUD LOGIC ---

        function openAddModal() {
            document.getElementById('facultyForm').reset();
            document.getElementById('formAction').value = 'add';
            document.getElementById('f_id').value = '';
            document.getElementById('modalTitle').innerText = 'Add New Faculty';
            modal.show();
        }

        async function editFaculty(id) {
            // Fetch Data
            const formData = new FormData();
            formData.append('action', 'fetch_single');
            formData.append('faculty_id', id);

            const res = await fetch('../api/admin/save_faculty.php', { method: 'POST', body: formData });
            const data = await res.json();

            // Fill Form
            document.getElementById('f_id').value = data.faculty_id;
            document.getElementById('f_fname').value = data.first_name;
            document.getElementById('f_lname').value = data.last_name;
            document.getElementById('f_email').value = data.email;
            document.getElementById('f_phone').value = data.phone;
            document.getElementById('f_dept').value = data.course_code;
            document.getElementById('f_desig').value = data.designation;
            document.getElementById('f_qual').value = data.qualification;
            document.getElementById('f_spec').value = data.specialization;
            document.getElementById('f_doj').value = data.date_of_joining;

            document.getElementById('formAction').value = 'update';
            document.getElementById('modalTitle').innerText = 'Edit Faculty: ' + data.first_name;
            modal.show();
        }

        async function viewFaculty(id) {
            const formData = new FormData();
            formData.append('action', 'fetch_single');
            formData.append('faculty_id', id);

            const res = await fetch('../api/admin/save_faculty.php', { method: 'POST', body: formData });
            const data = await res.json();

            document.getElementById('v_photo').src = data.profile_photo ? '../'+data.profile_photo : 'https://via.placeholder.com/100';
            document.getElementById('v_name').innerText = data.first_name + ' ' + data.last_name;
            document.getElementById('v_desig_dept').innerText = data.designation; // Can append dept name if fetched
            document.getElementById('v_id').innerText = data.faculty_id;
            document.getElementById('v_email').innerText = data.email;
            document.getElementById('v_phone').innerText = data.phone;
            document.getElementById('v_qual').innerText = data.qualification;
            document.getElementById('v_spec').innerText = data.specialization;
            document.getElementById('v_doj').innerText = data.date_of_joining;
            
            const badge = document.getElementById('v_status');
            badge.innerText = data.status.toUpperCase();
            badge.className = 'badge ' + (data.status === 'active' ? 'bg-success' : 'bg-danger');

            viewModal.show();
        }

        async function toggleStatus(id, currentStatus) {
            if(!confirm('Change status of this faculty?')) return;
            const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
            const formData = new FormData();
            formData.append('action', 'toggle_status');
            formData.append('faculty_id', id);
            formData.append('status', newStatus);

            const res = await fetch('../api/admin/save_faculty.php', { method: 'POST', body: formData });
            const result = await res.json();
            if(result.status === 'success') location.reload();
            else alert(result.message);
        }

        async function deleteFaculty(id) {
            if(!confirm('Are you sure? This will move faculty to Recycle Bin.')) return;
            
            const formData = new FormData();
            formData.append('action', 'delete');
            formData.append('faculty_id', id);

            const res = await fetch('../api/admin/save_faculty.php', { method: 'POST', body: formData });
            const result = await res.json();
            
            if(result.status === 'success') {
                alert(result.message);
                location.reload();
            } else {
                alert(result.message);
            }
        }

        // Handle Form Submit (Add/Update)
        document.getElementById('facultyForm').onsubmit = async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            
            const res = await fetch('../api/admin/save_faculty.php', { method: 'POST', body: formData });
            const result = await res.json();
            
            if(result.status === 'success') {
                alert(result.message);
                location.reload();
            } else {
                alert(result.message);
            }
        };
    </script>
</body>
</html>