<?php
require_once '../includes/auth_session.php';
require_once '../config/db.php';
checkLogin('ADMIN');

if (!isset($_GET['id'])) {
    header("Location: applications.php");
    exit();
}

$app_id = $_GET['id'];
$msg = "";

// Handle Form Submission (Admin updates Quota/Status)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $quota = $_POST['quota_type']; // Matches the name attribute in select
    $remarks = $_POST['admin_remarks'];
    $status = $_POST['app_status'];

    // FIX: Changed 'quota' to 'quota_type' in the SQL query
    $update = $conn->prepare("UPDATE admission_applications SET quota_type=?, admin_remarks=?, app_status=? WHERE application_no=?");
    
    if($update->execute([$quota, $remarks, $status, $app_id])) {
        $msg = "<div class='alert alert-success'>Application Updated Successfully!</div>";
    } else {
        $msg = "<div class='alert alert-danger'>Failed to update application.</div>";
    }
}

// Fetch Application Details (Joined with users and course_master)
$stmt = $conn->prepare("SELECT a.*, u.username, u.email, u.mobile_no, c.course_name 
                        FROM admission_applications a 
                        JOIN users u ON a.user_uid = u.user_uid 
                        JOIN course_master c ON a.course_code = c.course_code 
                        WHERE a.application_no = ?");
$stmt->execute([$app_id]);
$app = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$app) {
    die("Application not found.");
}

// Fetch Marks
$stmt_marks = $conn->prepare("SELECT * FROM admission_marks WHERE application_no = ?");
$stmt_marks->execute([$app_id]);
$marks = $stmt_marks->fetchAll(PDO::FETCH_ASSOC);

// Fetch Family Details
$stmt_fam = $conn->prepare("SELECT * FROM admission_family WHERE application_no = ?");
$stmt_fam->execute([$app_id]);
$family = $stmt_fam->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Review Application | NLPTC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .form-control-plaintext { font-weight: 500; color: #333; }
        .section-title { border-bottom: 2px solid #eee; padding-bottom: 10px; margin-bottom: 20px; color: #0d6efd; font-weight: bold; }
    </style>
</head>
<body class="bg-light">

    <?php include 'includes/sidebar.php'; ?>

    <div class="content" style="margin-left: 250px; padding: 30px;">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <a href="applications.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to List</a>
            <h4>Application Review: <span class="text-primary"><?= $app['application_no'] ?></span></h4>
        </div>

        <div class="card shadow mb-4">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Student Profile</h5>
                <span class="badge bg-light text-dark fs-6"><?= $app['app_status'] ?></span>
            </div>
            <div class="card-body">
                <?= $msg ?>

                <h6 class="section-title">Personal Information</h6>
                <div class="row g-3 mb-4">
                    <div class="col-md-4">
                        <label class="text-muted">Student Name</label>
                        <p class="form-control-plaintext"><?= $app['student_name'] ?></p>
                    </div>
                    <div class="col-md-4">
                        <label class="text-muted">Email</label>
                        <p class="form-control-plaintext"><?= $app['student_email'] ?></p>
                    </div>
                    <div class="col-md-4">
                        <label class="text-muted">Phone</label>
                        <p class="form-control-plaintext"><?= $app['student_mobile'] ?></p>
                    </div>
                    <div class="col-md-4">
                        <label class="text-muted">DOB / Age</label>
                        <p class="form-control-plaintext"><?= $app['dob'] ?> (<?= $app['age'] ?> Yrs)</p>
                    </div>
                    <div class="col-md-4">
                        <label class="text-muted">Gender</label>
                        <p class="form-control-plaintext"><?= $app['gender'] ?></p>
                    </div>
                    <div class="col-md-4">
                        <label class="text-muted">Community</label>
                        <p class="form-control-plaintext"><?= $app['community_class'] ?></p>
                    </div>
                    <div class="col-md-4">
                        <label class="text-muted">Aadhar No</label>
                        <p class="form-control-plaintext"><?= $app['aadhar_no'] ?></p>
                    </div>
                    <div class="col-md-8">
                        <label class="text-muted">Address</label>
                        <p class="form-control-plaintext"><?= $app['address_communication'] ?></p>
                    </div>
                </div>

                <h6 class="section-title">Academic Details</h6>
                <div class="row g-3 mb-3">
                    <div class="col-md-4"><label class="text-muted">Course Applied</label><p class="fw-bold"><?= $app['course_name'] ?></p></div>
                    <div class="col-md-4"><label class="text-muted">Admission Type</label><p class="fw-bold"><?= $app['admission_type'] ?></p></div>
                    <div class="col-md-4"><label class="text-muted">Total Percentage</label><p class="fw-bold text-success"><?= $app['calculated_percentage'] ?>%</p></div>
                </div>
                
                <table class="table table-bordered table-sm w-75 mb-4">
                    <thead class="table-light"><tr><th>Subject</th><th>Marks Secured</th><th>Max Marks</th></tr></thead>
                    <tbody>
                        <?php foreach($marks as $m): ?>
                        <tr>
                            <td><?= $m['subject_name'] ?></td>
                            <td><?= $m['marks_obtained'] ?></td>
                            <td><?= $m['max_marks'] ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <h6 class="section-title">Family Details</h6>
                <div class="row g-3 mb-4">
                    <?php foreach($family as $f): ?>
                    <div class="col-md-4">
                        <label class="text-muted"><?= $f['relation_type'] ?>'s Name</label>
                        <p class="fw-bold"><?= $f['name'] ?></p>
                        <small>Occ: <?= $f['occupation'] ?> | Mobile: <?= $f['mobile_no'] ?></small>
                    </div>
                    <?php endforeach; ?>
                </div>

                <form method="POST">
                    <div class="card bg-light border-warning mb-3">
                        <div class="card-header fw-bold text-warning"><i class="fas fa-user-shield"></i> OFFICE USE ONLY (Update Status)</div>
                        <div class="card-body">
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <label class="form-label fw-bold">Admission Quota <span class="text-danger">*</span></label>
                                    <select name="quota_type" class="form-select" required>
                                        <option value="" disabled <?= empty($app['quota_type']) ? 'selected' : '' ?>>Select Quota</option>
                                        <option value="GQ" <?= $app['quota_type'] == 'GQ' ? 'selected' : '' ?>>Government Quota (GQ)</option>
                                        <option value="MQ" <?= $app['quota_type'] == 'MQ' ? 'selected' : '' ?>>Management Quota (MQ)</option>
                                    </select>
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label fw-bold">Application Status</label>
                                    <select name="app_status" class="form-select">
                                        <option value="Submitted" <?= $app['app_status'] == 'Submitted' ? 'selected' : '' ?>>Submitted</option>
                                        <option value="Verified" <?= $app['app_status'] == 'Verified' ? 'selected' : '' ?>>Verified</option>
                                        <option value="Approved" <?= $app['app_status'] == 'Approved' ? 'selected' : '' ?>>Approved</option>
                                        <option value="Rejected" <?= $app['app_status'] == 'Rejected' ? 'selected' : '' ?>>Rejected</option>
                                    </select>
                                </div>

                                <div class="col-md-12">
                                    <label class="form-label fw-bold">Admin Remarks</label>
                                    <textarea name="admin_remarks" class="form-control" rows="2" placeholder="Any remarks for the student..."><?= $app['admin_remarks'] ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between">
                        <div>
                            <?php if($app['app_status'] == 'Approved'): ?>
                                <button type="button" onclick="admitStudent('<?= $app['application_no'] ?>')" class="btn btn-lg btn-success">
                                    <i class="fas fa-user-graduate"></i> Finalize Admission
                                </button>
                            <?php endif; ?>
                        </div>
                        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Updates</button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <script>
    async function admitStudent(appNo) {
        if(!confirm("Are you sure you want to ADMIT this student? This will generate a Student ID.")) return;

        const formData = new FormData();
        formData.append('app_no', appNo);

        try {
            const res = await fetch('../api/admin/finalize_admission.php', {
                method: 'POST',
                body: formData
            });
            const result = await res.json();

            if(result.status === 'success') {
                alert(result.message);
                window.location.reload();
            } else {
                alert("Error: " + result.message);
            }
        } catch(err) {
            alert("Network Error");
        }
    }
    </script>

</body>
</html>