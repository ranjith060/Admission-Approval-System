<?php
require_once '../includes/auth_session.php';
require_once '../config/db.php';
checkLogin('ADMIN');

// 1. Fetch Active Courses for Dropdown Filter
$course_list = $conn->query("SELECT * FROM course_master WHERE status='Active' ORDER BY course_name ASC");

// 2. Handle Filter Logic
$course_filter = $_GET['course'] ?? '';
$quota_filter = $_GET['quota'] ?? '';

// 3. Build Query for Report
$sql = "SELECT s.student_id, s.student_name, s.dob, s.gender, s.community, s.quota_type, 
               c.course_name, c.course_short,
               COALESCE(a.total_marks, 0) as qualifying_marks
        FROM student_master s
        JOIN course_master c ON s.course_code = c.course_code
        LEFT JOIN admission_applications a ON s.application_no = a.application_no
        WHERE s.status = 'Active'";

if (!empty($course_filter)) {
    $sql .= " AND s.course_code = '$course_filter'";
}
if (!empty($quota_filter)) {
    $sql .= " AND s.quota_type = '$quota_filter'";
}

$sql .= " ORDER BY s.student_name ASC";

$students = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>DOTE Report | NLPTC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>
</head>
<body>

    <?php include 'includes/sidebar.php'; ?>

    <div class="content">
        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold text-primary"><i class="fas fa-file-invoice"></i> DOTE Admission Report</h2>
            <div class="d-flex gap-2">
                <button onclick="exportTable()" class="btn btn-success">
                    <i class="fas fa-file-excel me-2"></i> Export Excel
                </button>
                <a href="dashboard.php" class="btn btn-secondary">Back</a>
            </div>
        </div>

        <div class="card shadow-sm border-0">
            <div class="card-body bg-light">
                <form class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Filter by Course</label>
                        <select name="course" class="form-select" onchange="this.form.submit()">
                            <option value="">All Courses</option>
                            <?php while($c = $course_list->fetch(PDO::FETCH_ASSOC)): ?>
                                <option value="<?= $c['course_code'] ?>" <?= $course_filter == $c['course_code'] ? 'selected' : '' ?>>
                                    <?= $c['course_name'] ?> (<?= $c['course_short'] ?>)
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Filter by Quota</label>
                        <select name="quota" class="form-select" onchange="this.form.submit()">
                            <option value="">All Quota</option>
                            <option value="GQ" <?= $quota_filter=='GQ'?'selected':'' ?>>Govt Quota (GQ)</option>
                            <option value="MQ" <?= $quota_filter=='MQ'?'selected':'' ?>>Mgmt Quota (MQ)</option>
                        </select>
                    </div>

                    <div class="col-md-2 d-flex align-items-end">
                        <a href="dote_reports.php" class="btn btn-outline-secondary w-100">Reset</a>
                    </div>
                </form>
            </div>
        </div>

        <br>

        <div class="card shadow-sm">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover mb-0" id="doteTable">
                        <thead class="table-dark text-center">
                            <tr>
                                <th>S.No</th>
                                <th>Student ID</th>
                                <th>Name</th>
                                <th>DOB</th>
                                <th>Gender</th>
                                <th>Community</th>
                                <th>Quota</th>
                                <th>Course</th>
                                <th>Qualifying Marks</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $i = 1;
                            if($students->rowCount() > 0):
                                while($row = $students->fetch(PDO::FETCH_ASSOC)): 
                            ?>
                            <tr>
                                <td class="text-center"><?= $i++ ?></td>
                                <td class="fw-bold"><?= $row['student_id'] ?></td>
                                <td><?= $row['student_name'] ?></td>
                                <td class="text-center"><?= date('d-m-Y', strtotime($row['dob'])) ?></td>
                                <td class="text-center"><?= $row['gender'] ?></td>
                                <td class="text-center"><?= $row['community'] ?></td>
                                <td class="text-center">
                                    <span class="badge bg-<?= $row['quota_type'] == 'GQ' ? 'primary' : 'warning text-dark' ?>">
                                        <?= $row['quota_type'] ?>
                                    </span>
                                </td>
                                <td><?= $row['course_name'] ?></td>
                                <td class="text-center"><?= $row['qualifying_marks'] ?></td>
                            </tr>
                            <?php endwhile; 
                            else: ?>
                                <tr><td colspan="9" class="text-center py-4 text-muted">No students found for this criteria.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        function exportTable() {
            var table = document.getElementById("doteTable");
            // Generate filename with timestamp
            var date = new Date().toISOString().slice(0,10);
            var wb = XLSX.utils.table_to_book(table, {sheet: "DOTE Report"});
            XLSX.writeFile(wb, "DOTE_Admission_Report_" + date + ".xlsx");
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>