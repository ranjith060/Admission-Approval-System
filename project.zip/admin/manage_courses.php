<?php
require_once '../includes/auth_session.php';
require_once '../config/db.php';
checkLogin('ADMIN');

$edit_mode = false;
$course_to_edit = [];
$msg = "";
$msg_type = "";

// --- HANDLE POST ACTIONS ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // 1. ADD NEW COURSE
    if (isset($_POST['add_course'])) {
        try {
            $stmt = $conn->prepare("INSERT INTO course_master (course_code, course_short, course_name, total_seats, duration_years, status) VALUES (?, ?, ?, ?, ?, 'Active')");
            if($stmt->execute([$_POST['code'], $_POST['short'], $_POST['name'], $_POST['seats'], $_POST['duration']])) {
                $msg = "Course Added Successfully!";
                $msg_type = "success";
            }
        } catch (PDOException $e) {
            $msg = "Error: " . $e->getMessage();
            $msg_type = "danger";
        }
    }

    // 2. UPDATE COURSE
    if (isset($_POST['update_course'])) {
        try {
            $stmt = $conn->prepare("UPDATE course_master SET course_short=?, course_name=?, total_seats=?, duration_years=? WHERE course_code=?");
            if($stmt->execute([$_POST['short'], $_POST['name'], $_POST['seats'], $_POST['duration'], $_POST['code']])) {
                $msg = "Course Updated Successfully!";
                $msg_type = "success";
            }
        } catch (PDOException $e) {
            $msg = "Error updating course: " . $e->getMessage();
            $msg_type = "danger";
        }
    }

    // 3. TOGGLE STATUS
    if (isset($_POST['toggle_status'])) {
        $new_status = $_POST['current_status'] == 'Active' ? 'Inactive' : 'Active';
        $stmt = $conn->prepare("UPDATE course_master SET status=? WHERE course_code=?");
        $stmt->execute([$new_status, $_POST['course_id']]);
        // Refresh to avoid resubmission issues
        header("Location: manage_courses.php");
        exit();
    }

    // 4. SOFT DELETE
    if (isset($_POST['delete_course'])) {
        $stmt = $conn->prepare("UPDATE course_master SET is_deleted=1 WHERE course_code=?");
        $stmt->execute([$_POST['course_id']]);
        $msg = "Course moved to Recycle Bin.";
        $msg_type = "warning";
    }
}

// --- HANDLE EDIT GET REQUEST ---
if (isset($_GET['edit'])) {
    $edit_mode = true;
    $stmt = $conn->prepare("SELECT * FROM course_master WHERE course_code = ?");
    $stmt->execute([$_GET['edit']]);
    $course_to_edit = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Manage Courses | NLPTC ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

    <?php include 'includes/sidebar.php'; ?>

    <div class="content">
        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold text-primary"><i class="fas fa-graduation-cap"></i> Manage Courses</h2>
            <a href="dashboard.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i> Back to Dashboard
            </a>
        </div>

        <?php if (!empty($msg)): ?>
            <div class="alert alert-<?= $msg_type ?> alert-dismissible fade show" role="alert">
                <?= $msg ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-4">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-dark text-white fw-bold">
                        <?= $edit_mode ? '<i class="fas fa-edit"></i> Edit Course' : '<i class="fas fa-plus-circle"></i> Add New Course' ?>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="manage_courses.php">
                            
                            <div class="mb-3">
                                <label class="form-label fw-bold">Course Code</label>
                                <input type="text" name="code" class="form-control" placeholder="1052" 
                                    value="<?= $edit_mode ? $course_to_edit['course_code'] : '' ?>" 
                                    <?= $edit_mode ? 'readonly' : 'required' ?>>
                                <?php if($edit_mode): ?>
                                    <small class="text-muted">Unique Code cannot be changed.</small>
                                <?php endif; ?>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-bold">Short Name</label>
                                <input type="text" name="short" class="form-control" placeholder="CSE" 
                                    value="<?= $edit_mode ? $course_to_edit['course_short'] : '' ?>" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-bold">Full Name</label>
                                <input type="text" name="name" class="form-control" placeholder="Computer Engineering" 
                                    value="<?= $edit_mode ? $course_to_edit['course_name'] : '' ?>" required>
                            </div>

                            <div class="row">
                                <div class="col-6 mb-3">
                                    <label class="form-label fw-bold">Seats</label>
                                    <input type="number" name="seats" class="form-control" 
                                        value="<?= $edit_mode ? $course_to_edit['total_seats'] : '60' ?>">
                                </div>
                                <div class="col-6 mb-3">
                                    <label class="form-label fw-bold">Duration (Yrs)</label>
                                    <input type="number" name="duration" class="form-control" 
                                        value="<?= $edit_mode ? $course_to_edit['duration_years'] : '3' ?>">
                                </div>
                            </div>

                            <div class="d-grid gap-2">
                                <?php if($edit_mode): ?>
                                    <button type="submit" name="update_course" class="btn btn-warning fw-bold">
                                        <i class="fas fa-save"></i> Update Course
                                    </button>
                                    <a href="manage_courses.php" class="btn btn-outline-secondary">Cancel</a>
                                <?php else: ?>
                                    <button type="submit" name="add_course" class="btn btn-primary fw-bold">
                                        <i class="fas fa-save"></i> Save Course
                                    </button>
                                <?php endif; ?>
                            </div>

                        </form>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white fw-bold">
                        <i class="fas fa-list-ul me-2"></i> Existing Courses
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Code</th>
                                        <th>Course Name</th>
                                        <th class="text-center">Seats</th>
                                        <th class="text-center">Status</th>
                                        <th class="text-center">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $courses = $conn->query("SELECT * FROM course_master WHERE is_deleted=0 ORDER BY course_code ASC");
                                    while($row = $courses->fetch()):
                                        $statusClass = $row['status'] == 'Active' ? 'success' : 'secondary';
                                        $statusIcon = $row['status'] == 'Active' ? 'fa-toggle-on' : 'fa-toggle-off';
                                    ?>
                                    <tr>
                                        <td class="fw-bold text-secondary"><?= $row['course_code'] ?></td>
                                        <td>
                                            <div class="fw-bold"><?= $row['course_name'] ?></div>
                                            <span class="badge bg-info text-dark"><?= $row['course_short'] ?></span>
                                        </td>
                                        <td class="text-center"><?= $row['total_seats'] ?></td>
                                        
                                        <td class="text-center">
                                            <span class="badge bg-<?= $statusClass ?>"><?= $row['status'] ?></span>
                                        </td>

                                        <td class="text-center">
                                            <div class="btn-group" role="group">
                                                
                                                <a href="manage_courses.php?edit=<?= $row['course_code'] ?>" class="btn btn-sm btn-outline-primary" title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>

                                                <form method="POST" style="display:inline;">
                                                    <input type="hidden" name="course_id" value="<?= $row['course_code'] ?>">
                                                    <input type="hidden" name="current_status" value="<?= $row['status'] ?>">
                                                    <button type="submit" name="toggle_status" class="btn btn-sm btn-outline-warning" title="Toggle Status">
                                                        <i class="fas fa-power-off"></i>
                                                    </button>
                                                </form>

                                                <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to move this course to the Recycle Bin?');">
                                                    <input type="hidden" name="course_id" value="<?= $row['course_code'] ?>">
                                                    <button type="submit" name="delete_course" class="btn btn-sm btn-outline-danger" title="Delete">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                </form>

                                            </div>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>