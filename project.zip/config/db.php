<?php
$host = "localhost";
$db_name = "nlptc318_erp"; // Unga database name check pannikonga
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die(json_encode(["status" => "error", "message" => "Connection Failed: " . $e->getMessage()]));
}
?>