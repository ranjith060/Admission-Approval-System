<?php
session_start();
session_destroy(); // Destroy all session data
header("Location: index.php"); // Go back to Login
exit();
?>