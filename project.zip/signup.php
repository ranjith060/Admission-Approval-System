<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | NLPTC Admission System</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <style>
        body { 
            background-color: #f0f2f5; 
            height: 100vh; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
        }
        .login-container { 
            max-width: 900px; 
            width: 100%; 
            background: white; 
            border-radius: 10px; 
            overflow: hidden; 
            box-shadow: 0 5px 20px rgba(0,0,0,0.1); 
        }
        .login-image { 
            background: linear-gradient(135deg, #198754, #157347); /* Green Gradient for Signup */
            color: white; 
            display: flex; 
            flex-direction: column; 
            justify-content: center; 
            padding: 40px; 
        }
        .login-form { 
            padding: 50px; 
        }
        .brand-title { 
            font-weight: bold; 
            font-size: 24px; 
            margin-bottom: 10px; 
        }
        .btn-register { 
            width: 100%; 
            padding: 12px; 
            font-size: 16px; 
            font-weight: bold; 
        }
        /* Mobile responsiveness adjustments */
        @media (max-width: 768px) {
            .login-container { max-width: 400px; }
            .login-form { padding: 30px; }
        }
    </style>
</head>
<body>

    <div class="container login-container">
        <div class="row g-0">
            
            <div class="col-md-6 login-image d-none d-md-flex">
                <h2 class="brand-title">Join NLPTC Family</h2>
                <p class="lead">Begin your journey with us today.</p>
                <hr style="border-color: rgba(255,255,255,0.5);">
                <p><i class="fas fa-check-circle me-2"></i> Easy Online Registration</p>
                <p><i class="fas fa-check-circle me-2"></i> Secure Data Handling</p>
                <p><i class="fas fa-check-circle me-2"></i> Fast Admission Process</p>
                <br>
                <small class="opacity-75">Admission & Approval Management System v1.0</small>
            </div>

            <div class="col-md-6 login-form">
                <div class="text-center mb-4">
                    <div class="bg-light rounded-circle d-inline-flex p-3 mb-3">
                        <i class="fas fa-user-plus fa-2x text-success"></i>
                    </div>
                    <h4>Create Account</h4>
                    <p class="text-muted">Fill in your details to register</p>
                </div>

                <form id="regForm" onsubmit="event.preventDefault(); registerUser();">
                    
                    <div class="mb-3">
                        <label class="form-label">Full Name</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light border-end-0"><i class="fas fa-user text-muted"></i></span>
                            <input type="text" id="username" class="form-control border-start-0 ps-0" placeholder="Your Name" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Email Address</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light border-end-0"><i class="fas fa-envelope text-muted"></i></span>
                            <input type="email" id="email" class="form-control border-start-0 ps-0" placeholder="student@example.com" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Mobile Number (10 Digits)</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light border-end-0"><i class="fas fa-phone text-muted"></i></span>
                            <input type="text" id="mobile" class="form-control border-start-0 ps-0" 
                                   maxlength="10" pattern="\d{10}" 
                                   oninput="this.value=this.value.replace(/[^0-9]/g,'')" 
                                   placeholder="9876543210" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Password</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light border-end-0"><i class="fas fa-lock text-muted"></i></span>
                            <input type="password" id="password" class="form-control border-start-0 ps-0" placeholder="••••••••" required>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-success btn-register">Register Now</button>
                    
                    <div class="text-center mt-3">
                        <p class="small">Already registered? <a href="index.php" class="text-success fw-bold text-decoration-none">Login Here</a></p>
                    </div>
                </form>

                <div id="response" class="alert alert-danger mt-3 d-none text-center"></div>
            </div>

        </div>
    </div>

    <script>
        async function registerUser() {
            const btn = document.querySelector('.btn-register');
            const alertBox = document.getElementById('response');
            
            // Get Values
            const data = {
                username: document.getElementById('username').value.trim(),
                email: document.getElementById('email').value.trim(),
                mobile: document.getElementById('mobile').value.trim(),
                password: document.getElementById('password').value.trim()
            };

            // Validation (Double check)
            if(!data.username || !data.email || !data.mobile || !data.password) {
                alertBox.classList.remove('d-none', 'alert-success');
                alertBox.classList.add('alert-danger');
                alertBox.innerHTML = "Please fill in all fields.";
                return;
            }

            if(data.mobile.length !== 10) {
                alertBox.classList.remove('d-none', 'alert-success');
                alertBox.classList.add('alert-danger');
                alertBox.innerHTML = "Mobile number must be exactly 10 digits.";
                return;
            }

            // Loading State
            btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i> Processing...';
            btn.disabled = true;
            alertBox.classList.add('d-none');

            try {
                // Call API
                const res = await fetch('api/auth/register.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });

                // Check Response Text (Debugging)
                const text = await res.text();
                let result;
                
                try {
                    result = JSON.parse(text); // Try converting to JSON
                } catch(e) {
                    console.error("Server Error:", text); // Show PHP error in Console
                    throw new Error("Server Error (Invalid JSON output)");
                }
                
                alertBox.classList.remove('d-none', 'alert-success', 'alert-danger');
                
                if(result.status === 'success') {
                    // Success
                    alertBox.classList.add('alert-success');
                    alertBox.innerHTML = `<i class="fas fa-check-circle me-2"></i> ${result.message}`;
                    
                    // Redirect to Login
                    setTimeout(() => window.location.href = result.redirect, 2000);
                } else {
                    // Failure
                    alertBox.classList.add('alert-danger');
                    alertBox.innerHTML = `<i class="fas fa-exclamation-circle me-2"></i> ${result.message}`;
                    btn.innerHTML = "Register Now";
                    btn.disabled = false;
                }

            } catch (err) {
                // Network Error
                console.error(err);
                alertBox.classList.remove('d-none');
                alertBox.classList.add('alert-danger');
                alertBox.innerHTML = `<i class="fas fa-wifi me-2"></i> Network Error: ${err.message}`;
                btn.innerHTML = "Register Now";
                btn.disabled = false;
            }
        }
    </script>
</body>
</html>