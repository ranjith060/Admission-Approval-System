<?php
require_once '../includes/auth_session.php';
require_once '../config/db.php';
checkLogin();

$user_id = $_SESSION['user_uid'];

// Fetch Application Status
$stmt = $conn->prepare("SELECT application_no, app_status FROM admission_applications WHERE user_uid = ?");
$stmt->execute([$user_id]);
$app = $stmt->fetch(PDO::FETCH_ASSOC);

$status = $app ? $app['app_status'] : 'None';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Student Dashboard | NLPTC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-light">

    <nav class="navbar navbar-dark bg-primary px-4 shadow-sm">
        <span class="navbar-brand fw-bold">NLPTC Student Portal</span>
        <a href="../logout.php" class="btn btn-danger btn-sm"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </nav>

    <div class="container mt-5">
        <h3 class="mb-4">Welcome, <?php echo $_SESSION['username']; ?>!</h3>

        <div class="row">
            <div class="col-md-8 mx-auto">
                
                <?php if ($status == 'None'): ?>
                    <div class="card text-center p-5 shadow-sm">
                        <i class="fas fa-file-signature fa-4x text-primary mb-3"></i>
                        <h3>New Admission Open</h3>
                        <p class="text-muted">You haven't applied yet. Start your application now.</p>
                        <a href="admission_form.php" class="btn btn-primary btn-lg mt-3">Apply Now</a>
                    </div>

                <?php elseif ($status == 'Submitted' || $status == 'Verified'): ?>
                    <div class="card text-center p-5 shadow-sm border-warning">
                        <i class="fas fa-clock fa-4x text-warning mb-3"></i>
                        <h3 class="text-warning">Application Submitted</h3>
                        <p class="lead">App No: <strong><?php echo $app['application_no']; ?></strong></p>
                        <div class="alert alert-warning mt-3">
                            Your application is under verification. Please wait for Admin approval.
                        </div>
                        <a href="review_application.php" class="btn btn-outline-dark">View Application</a>
                    </div>

                <?php elseif ($status == 'Admitted'): ?>
                    <div class="card text-center p-5 shadow-sm border-success">
                        <i class="fas fa-user-graduate fa-4x text-success mb-3"></i>
                        <h3 class="text-success">Congratulations!</h3>
                        <p class="lead">You are now an official student.</p>
                        <div class="alert alert-success">
                            Admission Confirmed. Your Student ID has been generated.
                        </div>
                        <button class="btn btn-success">Download ID Card</button> </div>

                <?php elseif ($status == 'Rejected'): ?>
                    <div class="card text-center p-5 shadow-sm border-danger">
                        <i class="fas fa-times-circle fa-4x text-danger mb-3"></i>
                        <h3 class="text-danger">Application Rejected</h3>
                        <p>Please contact the college administration for details.</p>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>

</body>
</html>