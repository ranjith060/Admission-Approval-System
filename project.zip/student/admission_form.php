<?php
require_once '../includes/auth_session.php';
require_once '../config/db.php';
checkLogin();

$is_admin = ($_SESSION['role_code'] == 'ADMIN');
$courses = $conn->query("SELECT * FROM course_master WHERE status='Active'");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admission Form | NLPTC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-section { background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #ddd; border-left: 5px solid #0d6efd; }
        .section-title { font-weight: bold; color: #0d6efd; border-bottom: 1px solid #eee; padding-bottom: 10px; margin-bottom: 20px; }
        .required-star { color: red; }
    </style>
</head>
<body class="bg-light">

<div class="container py-4">
    <div class="text-center mb-4">
        <h2 class="fw-bold text-primary">APPLICATION FOR ADMISSION TO DIPLOMA COURSES</h2>
    </div>

    <form id="admissionForm">
        
        <div class="form-section">
            <h5 class="section-title">Course & Admission Details</h5>
            <div class="row g-3">
                <div class="col-md-4">
                    <label>Course Applied <span class="required-star">*</span></label>
                    <select name="course_code" class="form-select" required>
                        <option value="">Select Course</option>
                        <?php while($c = $courses->fetch(PDO::FETCH_ASSOC)) { echo "<option value='{$c['course_code']}'>{$c['course_name']}</option>"; } ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label>Admission Type <span class="required-star">*</span></label>
                    <select name="admission_type" id="admission_type" class="form-select" required onchange="updateMarksTable()">
                        <option value="">Select Type</option>
                        <option value="First Year">First Year (SSLC)</option>
                        <option value="Lateral Entry">Lateral Entry (HSC / ITI)</option>
                    </select>
                </div>
                <div class="col-md-4 d-none" id="qualification_div">
                    <label>Qualification <span class="required-star">*</span></label>
                    <select name="qualification" id="qualification" class="form-select" onchange="updateMarksTable()">
                        <option value="SSLC">SSLC</option>
                        <option value="HSC">HSC</option>
                        <option value="ITI">ITI</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="form-section">
            <h5 class="section-title">Reference Details</h5>
            <div class="row g-3">
                <div class="col-md-4">
                    <label>Reference Type <span class="required-star">*</span></label>
                    <select name="reference_type" id="reference_type" class="form-select" required onchange="toggleReference()">
                        <option value="Direct">Direct Admission</option>
                        <option value="Student">Student Reference</option>
                        <option value="Alumni">Alumni Reference</option>
                        <option value="Faculty">Faculty Reference</option>
                        <option value="Consultancy">Consultancy</option>
                    </select>
                </div>
                <div class="col-md-4 ref-field d-none" id="ref_name_div"><label>Referrer Name</label><input type="text" name="ref_name" class="form-control"></div>
                <div class="col-md-4 ref-field d-none" id="ref_year_div"><label>Year</label><input type="text" name="ref_year" class="form-control"></div>
                <div class="col-md-4 ref-field d-none" id="ref_dept_div"><label>Department</label><input type="text" name="ref_department" class="form-control"></div>
                <div class="col-md-4 ref-field d-none" id="ref_desig_div"><label>Designation</label><input type="text" name="ref_designation" class="form-control"></div>
                <div class="col-md-4 ref-field d-none" id="ref_contact_div"><label>Contact No</label><input type="text" name="ref_contact" class="form-control"></div>
            </div>
        </div>

        <div class="form-section">
            <h5 class="section-title">Personal Information</h5>
            <div class="row g-3">
                <div class="col-md-4"><label>Name <span class="required-star">*</span></label><input type="text" name="student_name" class="form-control" required></div>
                <div class="col-md-4"><label>DOB <span class="required-star">*</span></label><input type="date" name="dob" id="dob" class="form-control" required onchange="calculateAge()"></div>
                <div class="col-md-2"><label>Age</label><input type="text" name="age" id="age" class="form-control" readonly></div>
                <div class="col-md-2"><label>Gender <span class="required-star">*</span></label>
                    <select name="gender" class="form-select" required><option>Male</option><option>Female</option><option>Transgender</option></select>
                </div>
                <div class="col-md-4"><label>Community <span class="required-star">*</span></label>
                    <select name="community" class="form-select" required><option>BC</option><option>MBC</option><option>SC</option><option>ST</option><option>OC</option></select>
                </div>
                <div class="col-md-4"><label>Caste</label><input type="text" name="caste_name" class="form-control" required></div>
                <div class="col-md-4"><label>Religion</label><input type="text" name="religion" class="form-control" required></div>
                <div class="col-md-4"><label>Mother Tongue</label><input type="text" name="mother_tongue" class="form-control" required></div>
                <div class="col-md-4"><label>Aadhar No (12 Digits) <span class="required-star">*</span></label><input type="text" name="aadhar_no" class="form-control" maxlength="12" pattern="\d{12}" required></div>
                <div class="col-md-4"><label>EMIS No</label><input type="text" name="emis_no" class="form-control"></div>
                <div class="col-md-4"><label>Blood Group</label><input type="text" name="blood_group" class="form-control"></div>
                <div class="col-md-4"><label>Student Mobile <span class="required-star">*</span></label><input type="text" name="student_mobile" class="form-control" maxlength="10" pattern="\d{10}" required></div>
                <div class="col-md-4"><label>Email</label><input type="email" name="student_email" class="form-control" required></div>
                <div class="col-12"><label>Address</label><textarea name="address_communication" class="form-control" required></textarea></div>
            </div>
        </div>

        <div class="form-section">
            <h5 class="section-title">Parent Details</h5>
            <div class="row g-3">
                <div class="col-12 fw-bold text-secondary">Father</div>
                <div class="col-md-4"><label>Name</label><input type="text" name="father_name" class="form-control" required></div>
                <div class="col-md-4"><label>Mobile</label><input type="text" name="father_mobile" class="form-control" maxlength="10" required></div>
                <div class="col-md-4"><label>Occupation</label><input type="text" name="father_occupation" class="form-control" required></div>
                <div class="col-md-4"><label>Annual Income</label><input type="number" name="father_income" class="form-control"></div>
                <div class="col-md-8"><label>Address</label><input type="text" name="father_address" class="form-control"></div>

                <div class="col-12 fw-bold text-secondary mt-2">Mother</div>
                <div class="col-md-4"><label>Name</label><input type="text" name="mother_name" class="form-control" required></div>
                <div class="col-md-4"><label>Mobile</label><input type="text" name="mother_mobile" class="form-control" maxlength="10"></div>
                <div class="col-md-4"><label>Occupation</label><input type="text" name="mother_occupation" class="form-control"></div>
                <div class="col-md-4"><label>Annual Income</label><input type="number" name="mother_income" class="form-control"></div>
                <div class="col-md-8"><label>Address</label><input type="text" name="mother_address" class="form-control"></div>
            </div>
        </div>

        <div class="form-section">
            <h5 class="section-title">School Details</h5>
            <div class="row g-3">
                <div class="col-md-6"><label>School Name</label><input type="text" name="school_name" class="form-control" required></div>
                <div class="col-md-6"><label>Place</label><input type="text" name="school_place" class="form-control" required></div>
                <div class="col-md-4"><label>Register No</label><input type="text" name="school_reg_no" class="form-control" required></div>
                <div class="col-md-4"><label>Passing Year</label><input type="number" name="year_of_passing" class="form-control" required></div>
                <div class="col-md-4"><label>Board</label><input type="text" name="board_of_study" class="form-control" required></div>
                <div class="col-md-4"><label>Medium</label><input type="text" name="medium_of_instruction" class="form-control" required></div>
                <div class="col-md-4"><label>Part 1 Lang</label><input type="text" name="part_1_language" class="form-control" required></div>
            </div>
        </div>

        <div class="form-section">
            <h5 class="section-title">Marks</h5>
            <table class="table table-bordered">
                <thead><tr><th>Subject</th><th>Max Marks</th><th>Secured</th></tr></thead>
                <tbody id="marks_body"></tbody>
                <tfoot>
                    <tr>
                        <th class="text-end">Total</th>
                        <th><input type="text" name="max_total_marks" id="max_total" class="form-control" readonly></th>
                        <th><input type="text" name="total_marks" id="sec_total" class="form-control" readonly></th>
                    </tr>
                    <tr><th class="text-end">Percentage</th><th colspan="2"><input type="text" name="percentage" id="percentage" class="form-control" readonly></th></tr>
                </tfoot>
            </table>
        </div>

        <div class="form-section">
            <h5 class="section-title">Bank & Facilities</h5>
            <div class="row g-3">
                <div class="col-md-3"><label>Bank Name</label><input type="text" name="bank_name" class="form-control"></div>
                <div class="col-md-3"><label>Branch</label><input type="text" name="bank_branch" class="form-control"></div>
                <div class="col-md-3"><label>Account No</label><input type="text" name="account_no" class="form-control"></div>
                <div class="col-md-3"><label>IFSC</label><input type="text" name="ifsc_code" class="form-control"></div>
                
                <div class="col-md-4">
                    <label>Transport Needed?</label>
                    <select name="transport_required" id="trans_req" class="form-select" onchange="toggleTrans()"><option>No</option><option>Yes</option></select>
                </div>
                <div class="col-md-4 d-none" id="trans_place"><label>Place</label><input type="text" name="transport_place" class="form-control"></div>
                <div class="col-md-4"><label>Hostel Needed?</label><select name="hostel_required" class="form-select"><option>No</option><option>Yes</option></select></div>
            </div>
        </div>

        <div class="d-grid gap-2 mb-5">
            <button type="submit" class="btn btn-success btn-lg">Submit Application</button>
        </div>
    </form>
</div>
<script>
    // 1. Calculate Age
    function calculateAge() {
        const dobVal = document.getElementById('dob').value;
        if(dobVal) {
            const dob = new Date(dobVal);
            const diff_ms = Date.now() - dob.getTime();
            const age_dt = new Date(diff_ms); 
            document.getElementById('age').value = Math.abs(age_dt.getUTCFullYear() - 1970);
        }
    }

    // 2. Transport Toggle
    function toggleTrans() {
        const req = document.getElementById('trans_req').value;
        const place = document.getElementById('trans_place');
        if(req === 'Yes') {
            place.classList.remove('d-none');
        } else {
            place.classList.add('d-none');
        }
    }

    // 3. Reference Logic
    function toggleReference() {
        const type = document.getElementById('reference_type').value;
        const ids = ['ref_name_div', 'ref_year_div', 'ref_dept_div', 'ref_desig_div', 'ref_contact_div'];
        ids.forEach(id => document.getElementById(id).classList.add('d-none'));

        if(type === 'Student' || type === 'Alumni') {
            ['ref_name_div', 'ref_year_div', 'ref_dept_div'].forEach(id => document.getElementById(id).classList.remove('d-none'));
        } else if(type === 'Faculty') {
            ['ref_name_div', 'ref_dept_div', 'ref_desig_div'].forEach(id => document.getElementById(id).classList.remove('d-none'));
        } else if(type === 'Consultancy') {
            ['ref_name_div', 'ref_contact_div'].forEach(id => document.getElementById(id).classList.remove('d-none'));
        }
    }

    // 4. Marks Logic
    function updateMarksTable() {
        const type = document.getElementById('admission_type').value;
        const qualDiv = document.getElementById('qualification_div');
        const qualSelect = document.getElementsByName('qualification')[0];
        const tbody = document.getElementById('marks_body');
        
        tbody.innerHTML = '';
        let subjects = [];

        if (type === 'First Year') {
            qualDiv.classList.add('d-none');
            // Auto set SSLC
            qualSelect.value = 'SSLC';
            subjects = ['Tamil', 'English', 'Mathematics', 'Science', 'Social Science'];
        } else {
            qualDiv.classList.remove('d-none');
            subjects = ['Subject 1', 'Subject 2', 'Subject 3', 'Subject 4', 'Subject 5', 'Subject 6'];
        }

        subjects.forEach(sub => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><input type="text" class="form-control" name="sub_name[]" value="${sub}" ${type === 'First Year' ? 'readonly' : ''}></td>
                <td><input type="number" class="form-control max-mark" name="sub_max[]" value="100" oninput="calcTotal()"></td>
                <td><input type="number" class="form-control sec-mark" name="sub_obt[]" oninput="calcTotal()" required></td>
            `;
            tbody.appendChild(tr);
        });
        calcTotal();
    }

    function calcTotal() {
        let max = 0, sec = 0;
        document.querySelectorAll('.max-mark').forEach(el => max += Number(el.value || 0));
        document.querySelectorAll('.sec-mark').forEach(el => sec += Number(el.value || 0));
        document.getElementById('max_total').value = max;
        document.getElementById('sec_total').value = sec;
        document.getElementById('percentage').value = (max > 0) ? ((sec/max)*100).toFixed(2) + '%' : '0%';
    }

    // Initialize on load
    updateMarksTable();

    // 5. SUBMIT HANDLER
    document.getElementById('admissionForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const btn = this.querySelector('button[type="submit"]');
        btn.disabled = true;
        btn.innerText = "Submitting...";

        try {
            // Collect Marks Data manually into an array
            let marks = [];
            const rows = document.querySelectorAll('#marks_body tr');
            rows.forEach(row => {
                const inputs = row.querySelectorAll('input');
                marks.push({
                    subject: inputs[0].value,
                    max: inputs[1].value,
                    obtained: inputs[2].value
                });
            });

            // Create FormData object
            const formData = new FormData(this);
            // Append marks as JSON string
            formData.append('marks_json', JSON.stringify(marks));

            // Log data for debugging (Press F12 -> Console to see)
            console.log("Submitting Data:", Object.fromEntries(formData));

            const res = await fetch('../api/student/submit_application.php', {
                method: 'POST',
                body: formData
            });

            const text = await res.text();
            console.log("Server Response:", text); // Debugging

            try {
                const result = JSON.parse(text);
                if(result.status === 'success') {
                    alert(result.message);
                    // Redirect to docs page
                    if(result.message.includes("App No:")) {
                         const appNo = result.message.split('App No: ')[1];
                         window.location.href = 'upload_documents.php?app_no=' + appNo;
                    } else {
                         window.location.reload();
                    }
                } else {
                    alert("Error: " + result.message);
                    btn.disabled = false;
                    btn.innerText = "Submit Application";
                }
            } catch (jsonErr) {
                console.error("JSON Error:", jsonErr);
                alert("Server Error. Check console for details.");
                btn.disabled = false;
                btn.innerText = "Submit Application";
            }

        } catch (err) {
            console.error("Fetch Error:", err);
            alert("Network Error. Please try again.");
            btn.disabled = false;
            btn.innerText = "Submit Application";
        }
    });
</script>

</body>
</html>