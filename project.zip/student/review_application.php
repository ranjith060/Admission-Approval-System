<?php
require_once '../includes/auth_session.php';
require_once '../config/db.php';
checkLogin('STUDENT');

$student_id = $_SESSION['user_uid'];

// Fetch All Details
$stmt = $conn->prepare("SELECT * FROM admission_applications WHERE user_uid = ?");
$stmt->execute([$student_id]);
$app = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$app) { echo "No Application Found!"; exit(); }

// Check if already submitted
if($app['app_status'] != 'Draft') {
    header("Location: dashboard.php"); // Already submitted na veliya anupidu
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Review Application | NLPTC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light p-5">
    <div class="container bg-white p-4 shadow rounded">
        <h3 class="text-center mb-4">Review Your Application</h3>
        
        <div class="alert alert-warning">
            <i class="fa fa-exclamation-triangle"></i> Please check all details carefully. Once submitted, you cannot edit.
        </div>

        <div class="row">
            <div class="col-md-6">
                <h5>Basic Details</h5>
                <p><strong>App No:</strong> <?= $app['application_no'] ?></p>
                <p><strong>Name:</strong> <?= $app['student_name'] ?></p>
                <p><strong>Course:</strong> <?= $app['course_code_pref'] ?></p>
                <p><strong>Mobile:</strong> <?= $_SESSION['mobile_no'] ?? 'N/A' ?></p>
            </div>
            <div class="col-md-6">
                <h5>Status</h5>
                <p><strong>Payment:</strong> <span class="badge bg-success">Completed</span> (Assuming Paid)</p>
                <p><strong>Documents:</strong> <span class="badge bg-info">Uploaded</span></p>
            </div>
        </div>

        <hr>
        
        <div class="form-check mb-4">
            <input class="form-check-input" type="checkbox" id="declare" required>
            <label class="form-check-label" for="declare">
                I hereby declare that all the information furnished above is true to the best of my knowledge.
            </label>
        </div>

        <div class="d-flex justify-content-between">
            <a href="admission_form.php" class="btn btn-secondary">Edit Details</a>
            <button onclick="finalSubmit('<?= $app['application_no'] ?>')" class="btn btn-primary btn-lg">Confirm & Submit Application</button>
        </div>
    </div>

    <script>
        async function finalSubmit(appNo) {
            if(!document.getElementById('declare').checked) {
                alert("Please accept the declaration!");
                return;
            }
            if(!confirm("Are you sure? You cannot edit after this.")) return;

            const formData = new FormData();
            formData.append('app_no', appNo);

            const res = await fetch('../api/admission/final_submit.php', {
                method: 'POST',
                body: formData
            });
            const result = await res.json();
            
            if(result.status === 'success') {
                alert("Application Submitted Successfully!");
                window.location.href = 'dashboard.php';
            } else {
                alert("Error: " + result.message);
            }
        }
    </script>
</body>
</html>