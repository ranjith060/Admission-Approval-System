<?php
require_once '../includes/auth_session.php';
require_once '../config/db.php';
checkLogin('STUDENT');

$student_id = $_SESSION['user_uid'];

// Fetch User Details (Phone & Email)
try {
    $stmt = $conn->prepare("SELECT username, email, mobile_no FROM users WHERE user_uid = ?");
    $stmt->execute([$student_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching profile: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Profile | NLPTC ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f4f6f9; }
        .sidebar { height: 100vh; width: 250px; position: fixed; top: 0; left: 0; background-color: #2c3e50; padding-top: 20px; color: white; }
        .sidebar a { padding: 15px 25px; text-decoration: none; font-size: 16px; color: #bdc3c7; display: block; }
        .sidebar a:hover, .sidebar a.active { background-color: #34495e; color: white; border-left: 4px solid #3498db; }
        .content { margin-left: 250px; padding: 20px; }
        .profile-card { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); max-width: 600px; margin: auto; }
        .form-control[readonly] { background-color: #e9ecef; cursor: not-allowed; } /* Gray out readonly fields */
    </style>
</head>
<body>

    <div class="sidebar">
        <h4 class="text-center mb-4">NLPTC ERP</h4>
        <a href="dashboard.php"><i class="fas fa-home me-2"></i> Dashboard</a>
        <a href="admission_form.php"><i class="fas fa-file-alt me-2"></i> Admission Form</a>
        <a href="upload_documents.php"><i class="fas fa-upload me-2"></i> Documents</a>
        <a href="#" class="active"><i class="fas fa-user-circle me-2"></i> Profile</a>
        <a href="../logout.php" class="text-danger"><i class="fas fa-sign-out-alt me-2"></i> Logout</a>
    </div>

    <div class="content">
        <h3 class="text-center mb-4">My Profile Settings</h3>
        
        <div class="profile-card">
            <div class="text-center mb-4">
                <i class="fas fa-user-circle fa-5x text-secondary"></i>
                <h4 class="mt-2"><?php echo htmlspecialchars($user['username']); ?></h4>
                <span class="badge bg-primary">Student</span>
            </div>

            <div class="mb-3">
                <label class="form-label fw-bold">Registered Mobile Number</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-phone"></i></span>
                    <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['mobile_no']); ?>" readonly>
                    <span class="input-group-text"><i class="fas fa-lock text-muted"></i></span>
                </div>
                <small class="text-muted">You cannot change this number.</small>
            </div>

            <div class="mb-3">
                <label class="form-label fw-bold">Registered Email ID</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                    <input type="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" readonly>
                    <span class="input-group-text"><i class="fas fa-lock text-muted"></i></span>
                </div>
                <small class="text-muted">You cannot change this email.</small>
            </div>

            <hr class="my-4">

            <h5 class="mb-3"><i class="fas fa-key me-2"></i>Change Password</h5>
            <form id="passwordForm">
                <div class="mb-3">
                    <label class="form-label">Current Password</label>
                    <input type="password" name="current_password" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">New Password</label>
                    <input type="password" name="new_password" class="form-control" minlength="6" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Confirm New Password</label>
                    <input type="password" name="confirm_password" class="form-control" minlength="6" required>
                </div>

                <button type="button" onclick="updatePassword()" class="btn btn-warning w-100 fw-bold">Update Password</button>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        async function updatePassword() {
            const form = document.getElementById('passwordForm');
            if (!form.checkValidity()) {
                form.reportValidity();
                return;
            }

            const formData = new FormData(form);
            
            // Basic Frontend Validation
            if(formData.get('new_password') !== formData.get('confirm_password')) {
                alert("New Password and Confirm Password do not match!");
                return;
            }

            try {
                const res = await fetch('../api/auth/change_password.php', {
                    method: 'POST',
                    body: formData
                });
                const result = await res.json();
                
                if(result.status === 'success') {
                    alert("Success: " + result.message);
                    form.reset();
                } else {
                    alert("Error: " + result.message);
                }
            } catch (err) {
                alert("Network Error. Please try again.");
            }
        }
    </script>
</body>
</html>