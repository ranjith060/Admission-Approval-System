<?php
require_once '../includes/auth_session.php';
require_once '../config/db.php';
checkLogin();

if (!isset($_GET['app_no'])) {
    header("Location: dashboard.php");
    exit();
}

$app_no = $_GET['app_no'];

// List of Documents
$documents = [
    'AADHAR' => ['label' => 'Aadhar Card', 'required' => true],
    'COMMUNITY' => ['label' => 'Community Certificate', 'required' => true],
    'INCOME' => ['label' => 'Income Certificate', 'required' => true],
    'BANK_PASSBOOK' => ['label' => 'Bank Passbook (Front Page)', 'required' => true],
    'PHOTO' => ['label' => 'Student Photo', 'required' => true],
    'SSLC_MARK' => ['label' => 'SSLC Mark Sheet', 'required' => false], // Optional
    'HSC_MARK' => ['label' => 'HSC / ITI Mark Sheet', 'required' => false], // Optional
    'TC' => ['label' => 'Transfer Certificate (TC)', 'required' => false] // Optional
];

// Fetch Uploaded Docs status
$uploaded_docs = [];
$stmt = $conn->prepare("SELECT doc_type, verification_status FROM admission_documents WHERE application_no = ?");
$stmt->execute([$app_no]);
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $uploaded_docs[$row['doc_type']] = $row['verification_status'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Upload Documents | NLPTC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .doc-card { border-left: 5px solid #0d6efd; transition: 0.3s; }
        .doc-card.uploaded { border-left-color: #198754; background-color: #f8fff9; }
        .required-badge { font-size: 0.8rem; vertical-align: top; }
    </style>
</head>
<body class="bg-light">

<div class="container py-5">
    <div class="card shadow">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h4 class="mb-0"><i class="fas fa-file-upload me-2"></i> Upload Documents</h4>
            <span>App No: <strong><?= $app_no ?></strong></span>
        </div>
        <div class="card-body">
            
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i> 
                <strong>Note:</strong> Upload clear scanned copies (JPG, PNG, PDF). Max size 2MB. 
                <span class="text-danger">* Marks Mandatory fields.</span>
            </div>

            <div class="row g-4">
                <?php foreach ($documents as $code => $info): 
                    $is_uploaded = isset($uploaded_docs[$code]);
                    $status = $is_uploaded ? $uploaded_docs[$code] : 'Not Uploaded';
                    $card_class = $is_uploaded ? 'uploaded' : '';
                    $btn_class = $is_uploaded ? 'btn-success' : 'btn-outline-primary';
                    $btn_text = $is_uploaded ? 'Re-Upload' : 'Upload';
                    $icon = $is_uploaded ? '<i class="fas fa-check-circle text-success float-end fa-2x"></i>' : '<i class="fas fa-clock text-secondary float-end fa-2x"></i>';
                ?>
                
                <div class="col-md-6">
                    <div class="card h-100 shadow-sm doc-card <?= $card_class ?>">
                        <div class="card-body">
                            <?= $icon ?>
                            <h5 class="card-title">
                                <?= $info['label'] ?>
                                <?php if($info['required']): ?>
                                    <span class="badge bg-danger required-badge">*</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary required-badge">Optional</span>
                                <?php endif; ?>
                            </h5>
                            
                            <p class="card-text text-muted small">Status: <strong><?= $status ?></strong></p>

                            <form class="upload-form" data-doc-type="<?= $code ?>">
                                <div class="input-group">
                                    <input type="file" class="form-control" name="file" required accept=".jpg,.png,.pdf">
                                    <button class="btn <?= $btn_class ?>" type="submit">
                                        <i class="fas fa-upload"></i> <?= $btn_text ?>
                                    </button>
                                </div>
                                <div class="progress mt-2 d-none" style="height: 5px;">
                                    <div class="progress-bar progress-bar-striped progress-bar-animated" style="width: 0%"></div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="text-center mt-5">
                <a href="dashboard.php" class="btn btn-primary btn-lg px-5">
                    <i class="fas fa-check"></i> Finish & Go to Dashboard
                </a>
            </div>

        </div>
    </div>
</div>

<script>
    document.querySelectorAll('.upload-form').forEach(form => {
        form.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const docType = this.dataset.docType;
            const fileInput = this.querySelector('input[type="file"]');
            const btn = this.querySelector('button');
            const progressBar = this.querySelector('.progress-bar');
            const progressContainer = this.querySelector('.progress');

            if(fileInput.files.length === 0) return alert("Select a file first!");

            const formData = new FormData();
            formData.append('application_no', '<?= $app_no ?>');
            formData.append('doc_type', docType);
            formData.append('file', fileInput.files[0]);

            // UI Changes
            btn.disabled = true;
            btn.innerHTML = 'Uploading...';
            progressContainer.classList.remove('d-none');
            progressBar.style.width = '50%';

            try {
                const res = await fetch('../api/student/upload_doc_api.php', {
                    method: 'POST',
                    body: formData
                });
                const result = await res.json();

                progressBar.style.width = '100%';
                
                if(result.status === 'success') {
                    setTimeout(() => {
                        alert("Uploaded Successfully!");
                        location.reload(); // Reload to update status colors
                    }, 500);
                } else {
                    alert("Error: " + result.message);
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-upload"></i> Upload';
                    progressContainer.classList.add('d-none');
                }

            } catch (err) {
                console.error(err);
                alert("Network Error");
                btn.disabled = false;
            }
        });
    });
</script>

</body>
</html>