<?php
class DoteAllotment {
    private $conn;
    
    // TN DOTE Reservation Rules (Form D Logic)
    private $rules = [
        'OC'  => 31.0,
        'BC'  => 26.5,
        'BCM' => 3.5,
        'MBC' => 20.0,
        'SC'  => 15.0,
        'SCA' => 3.0,
        'ST'  => 1.0
    ];

    public function __construct($db_conn) {
        $this->conn = $db_conn;
    }

    // FORM A: Merit List (Marks descending order)
    public function getMeritList($course_code) {
        $sql = "SELECT application_no, student_name, community_class, marks_obtained, calculated_percentage, app_status 
                FROM admission_applications 
                WHERE course_code_pref = ? AND app_status != 'Draft'
                ORDER BY calculated_percentage DESC";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([$course_code]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
// FORM B: Admitted Students List (Ordered by Quota -> Community)
    public function getAdmittedList($course_code) {
        // We select allotted_category as 'QUOTA' to match DOTE format
        $sql = "SELECT application_no, student_name, gender, community_class, allotted_category, 
                       marks_obtained, calculated_percentage, quota_type
                FROM admission_applications 
                WHERE course_code_pref = ? AND app_status = 'Admitted'
                ORDER BY quota_type, allotted_category, calculated_percentage DESC";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([$course_code]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // FORM F1 (Religion) & F2 (Language)
    public function getMinorityStats($course_code, $type) {
        $col = ($type == 'FORM_F1') ? 'religion' : 'mother_tongue';
        
        // Count Boys & Girls per Category
        $sql = "SELECT $col as name, 
                       SUM(CASE WHEN gender='Male' THEN 1 ELSE 0 END) as boys,
                       SUM(CASE WHEN gender='Female' THEN 1 ELSE 0 END) as girls
                FROM admission_applications 
                WHERE course_code_pref = ? AND app_status = 'Admitted'
                GROUP BY $col";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([$course_code]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    // FORM D: Seat Matrix Calculation (Sanctioned vs Admitted)
    public function getSeatMatrix($course_code) {
        // 1. Get Sanctioned Seats
        $stmt = $this->conn->prepare("SELECT total_seats FROM course_master WHERE course_code = ?");
        $stmt->execute([$course_code]);
        $total_seats = $stmt->fetchColumn() ?: 60; // Default 60 if error

        // 2. Split Quota (Assuming 50% Govt, 50% Mgmt as per practice, or 100% depending on rule)
        // Adjust this logic if your college surrenders 100% seats to Govt
        $gq_seats = floor($total_seats * 1.0); // Assuming 100% seats follow reservation for calculation
        
        // 3. Calculate Target Seats per Community
        $matrix = [];
        foreach ($this->rules as $comm => $percent) {
            $matrix[$comm] = round(($gq_seats * $percent) / 100);
        }

        // 4. Get Actual Admitted Count from DB
        $sql = "SELECT community_class, COUNT(*) as cnt 
                FROM admission_applications 
                WHERE course_code_pref = ? AND app_status = 'Admitted' 
                GROUP BY community_class";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([$course_code]);
        $actual_data = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

        return ['total' => $total_seats, 'target' => $matrix, 'actual' => $actual_data];
    }

    // FORM C: Boys/Girls Stats (Community Wise)
    public function getGenderStats($course_code) {
        $communities = array_keys($this->rules);
        $stats = [];
        
        // Initialize 0
        foreach ($communities as $comm) {
            $stats[$comm] = ['Male' => 0, 'Female' => 0];
        }

        $sql = "SELECT community_class, gender, COUNT(*) as cnt 
                FROM admission_applications 
                WHERE course_code_pref = ? AND app_status = 'Admitted'
                GROUP BY community_class, gender";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([$course_code]);
        
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $stats[$row['community_class']][$row['gender']] = $row['cnt'];
        }
        return $stats;
    }

    // FORM F1 (Religion) & F2 (Language) Logic
    public function getMinorityStats($course_code, $type) {
        $field = ($type == 'F1') ? 'religion' : 'mother_tongue';
        
        $sql = "SELECT $field as name, gender, COUNT(*) as cnt 
                FROM admission_applications 
                WHERE course_code_pref = ? AND app_status = 'Admitted'
                GROUP BY $field, gender";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([$course_code]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>