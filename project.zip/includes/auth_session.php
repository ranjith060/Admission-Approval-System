<?php
// Start Session only if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Function to Check Login & Role
function checkLogin($required_role = null) {
    
    // 1. Check if User is Logged In
    if (!isset($_SESSION['user_uid'])) {
        header("Location: ../index.php"); // Redirect to Login
        exit();
    }

    // 2. Check Role (Fix: Changed 'role' to 'role_code')
    if ($required_role !== null) {
        if (!isset($_SESSION['role_code']) || $_SESSION['role_code'] !== $required_role) {
            echo "<h3 style='color:red; text-align:center; margin-top:20%'>🚫 Access Denied! You are not authorized.</h3>";
            echo "<p style='text-align:center'><a href='../logout.php'>Logout</a></p>";
            exit();
        }
    }
}
?>