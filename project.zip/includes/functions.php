<?php
// includes/functions.php

function generateApplicationID($conn) {
    // 1. Get Academic Year
    $stmt = $conn->query("SELECT ay_short_code FROM academic_years WHERE status = 'Active' LIMIT 1");
    $ay = $stmt->fetch(PDO::FETCH_ASSOC);
    $year = $ay ? $ay['ay_short_code'] : date('y').(date('y')+1);

    // 2. Manage Sequence
    $seq_name = "SEQ_APP_" . $year;
    
    // Ensure sequence exists
    $conn->query("INSERT IGNORE INTO system_sequences (seq_code, last_value) VALUES ('$seq_name', 0)");
    
    // Increment
    $conn->query("UPDATE system_sequences SET last_value = last_value + 1 WHERE seq_code = '$seq_name'");
    
    // Get Value
    $stmt = $conn->query("SELECT last_value FROM system_sequences WHERE seq_code = '$seq_name'");
    $seq = $stmt->fetchColumn();

    // APP + 2526 + 0001
    return "APP" . $year . str_pad($seq, 4, '0', STR_PAD_LEFT);
}
?>