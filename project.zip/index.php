<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | NLPTC Admission System</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <style>
        body { 
            background-color: #f0f2f5; 
            height: 100vh; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
        }
        .login-container { 
            max-width: 900px; 
            width: 100%; 
            background: white; 
            border-radius: 10px; 
            overflow: hidden; 
            box-shadow: 0 5px 20px rgba(0,0,0,0.1); 
        }
        .login-image { 
            background: linear-gradient(135deg, #0d6efd, #0a58ca); 
            color: white; 
            display: flex; 
            flex-direction: column; 
            justify-content: center; 
            padding: 40px; 
        }
        .login-form { 
            padding: 50px; 
        }
        .brand-title { 
            font-weight: bold; 
            font-size: 24px; 
            margin-bottom: 10px; 
        }
        .btn-login { 
            width: 100%; 
            padding: 12px; 
            font-size: 16px; 
            font-weight: bold; 
        }
        /* Mobile responsiveness adjustments */
        @media (max-width: 768px) {
            .login-container { max-width: 400px; }
            .login-form { padding: 30px; }
        }
    </style>
</head>
<body>

    <div class="container login-container">
        <div class="row g-0">
            
            <div class="col-md-6 login-image d-none d-md-flex">
                <h2 class="brand-title">NLPTC Admission</h2>
                <p class="lead">Nanjiah Lingammal Polytechnic College</p>
                <hr style="border-color: rgba(255,255,255,0.5);">
                <p><i class="fas fa-check-circle me-2"></i> Online Admission</p>
                <p><i class="fas fa-check-circle me-2"></i> Document Verification</p>
                <p><i class="fas fa-check-circle me-2"></i> Real-time Approval</p>
                <br>
                <small class="opacity-75">Admission & Approval Management System v1.0</small>
            </div>

            <div class="col-md-6 login-form">
                <div class="text-center mb-4">
                    <div class="bg-light rounded-circle d-inline-flex p-3 mb-3">
                        <i class="fas fa-user-graduate fa-2x text-primary"></i>
                    </div>
                    <h4>Welcome Back!</h4>
                    <p class="text-muted">Please login to your account</p>
                </div>

                <form id="loginForm" onsubmit="event.preventDefault(); loginUser();">
                    <div class="mb-3">
                        <label class="form-label">Email Address</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light border-end-0"><i class="fas fa-envelope text-muted"></i></span>
                            <input type="email" id="email" class="form-control border-start-0 ps-0" placeholder="student@example.com" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Password</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light border-end-0"><i class="fas fa-lock text-muted"></i></span>
                            <input type="password" id="password" class="form-control border-start-0 ps-0" placeholder="••••••••" required>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary btn-login">Login</button>
                    
                    <div class="text-center mt-3">
                        <p class="small">Don't have an account? <a href="signup.php" class="text-primary fw-bold text-decoration-none">Register Here</a></p>
                    </div>
                </form>

                <div id="response" class="alert alert-danger mt-3 d-none text-center"></div>
            </div>

        </div>
    </div>

    <script>
        async function loginUser() {
            const btn = document.querySelector('.btn-login');
            const alertBox = document.getElementById('response');
            
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value.trim();

            if(!email || !password) {
                alertBox.classList.remove('d-none', 'alert-success');
                alertBox.classList.add('alert-danger');
                alertBox.textContent = "Please fill in both email and password.";
                return;
            }

            // Loading State
            btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i> Logging in...';
            btn.disabled = true;
            alertBox.classList.add('d-none');

            try {
                const res = await fetch('api/auth/login.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, password })
                });

                // Robust JSON Parsing
                const text = await res.text();
                let result;
                try {
                    result = JSON.parse(text);
                } catch(e) {
                    console.error("Raw Server Response:", text);
                    throw new Error("Server Error: Invalid JSON response. Check console.");
                }
                
                alertBox.classList.remove('d-none', 'alert-success', 'alert-danger');
                
                if(result.status === 'success') {
                    // Success
                    alertBox.classList.add('alert-success');
                    alertBox.innerHTML = `<i class="fas fa-check-circle me-2"></i> ${result.message}`;
                    
                    // Redirect after short delay
                    setTimeout(() => {
                        window.location.href = result.redirect;
                    }, 1000);
                } else {
                    // Fail (Wrong password/email)
                    alertBox.classList.add('alert-danger');
                    alertBox.innerHTML = `<i class="fas fa-exclamation-circle me-2"></i> ${result.message}`;
                    btn.innerHTML = 'Login';
                    btn.disabled = false;
                }

            } catch (err) {
                // Network/Code Error
                console.error(err);
                alertBox.classList.remove('d-none');
                alertBox.classList.add('alert-danger');
                alertBox.innerHTML = `<i class="fas fa-wifi me-2"></i> Network Error: ${err.message}`;
                btn.innerHTML = 'Login';
                btn.disabled = false;
            }
        }
    </script>
</body>
</html>